from dataclasses import asdict, replace


from pathlib import Path


import argparse


import gc


import json


import math


import os


import random


import shutil


import time


import zipfile


import numpy as np


import pyarrow as pa


import pyarrow.parquet as pq


import torch


from datasets import Dataset, concatenate_datasets, load_from_disk


from huggingface_hub import hf_hub_download


from tokenizers import Tokenizer


from transformers import get_cosine_schedule_with_warmup


import hw2_core as h


from safe_numeric import compare


PARAMETERS = 130_183_936


def prepare_training(run, tokenizer, shards, cfg, source):
    """Write int32 token IDs directly, without caching raw or intermediate Arrow."""
    token_dir = run / 'train_token_shards'
    token_dir.mkdir(exist_ok=True)
    manifest_path = run / 'data_manifest.json'
    signature = {'dataset': h.DATASET, 'revision': h.REVISION, 'shards': shards,
                 'tokenizer_sha256': h.file_hash(run / 'tokenizer.json'),
                 'max_source': cfg.max_source, 'max_target': cfg.max_target,
                 'split': 'normalized_question_sha256_mod_1000_lt_980'}
    if manifest_path.exists():
        if h.read_json(manifest_path)['signature'] != signature:
            raise ValueError('Training data signature changed')
        return concatenate_datasets([Dataset.from_file(str(token_dir / f'{i:05d}.arrow')) for i in range(shards)])
    schema = pa.schema([('source_ids', pa.list_(pa.int32())), ('target_ids', pa.list_(pa.int32())),
                        ('n_source', pa.int16()), ('n_target', pa.int16())])
    stats = {'signature': signature, 'raw_rows': 0, 'heldout_rows_excluded': 0,
             'overlength_rows_excluded': 0, 'train_rows': 0, 'targets_modified': False}
    for i in range(shards):
        destination = token_dir / f'{i:05d}.arrow'
        part_manifest = token_dir / f'{i:05d}.json'
        if destination.exists() and part_manifest.exists():
            part = h.read_json(part_manifest)
            if part['signature'] != signature:
                raise ValueError('Per-shard data signature changed')
            for key in ['raw_rows', 'heldout_rows_excluded', 'overlength_rows_excluded', 'train_rows']:
                stats[key] += part[key]
            print(json.dumps({'kind': 'data_progress', 'shard': i + 1, 'shards': shards, 'rows': stats['train_rows'], 'cached': True}), flush=True)
            continue
        previous = {key: stats[key] for key in ['raw_rows', 'heldout_rows_excluded', 'overlength_rows_excluded', 'train_rows']}
        temporary = destination.with_suffix('.tmp.arrow')
        with pa.OSFile(str(temporary), 'wb') as stream:
            with pa.ipc.new_stream(stream, schema) as writer:
                name = f'data/train/part-{i:05d}.parquet'
                path = source / name
                if not path.is_file():
                    print(json.dumps({'kind': 'download_start', 'shard': i + 1, 'file': name}), flush=True)
                    path = Path(hf_hub_download(h.DATASET, name, repo_type='dataset', revision=h.REVISION,
                                               local_dir=str(source), etag_timeout=20))
                for batch in pq.ParquetFile(path).iter_batches(batch_size=8192, columns=['question', 'code']):
                    batch = batch.to_pydict()
                    stats['raw_rows'] += len(batch['question'])
                    keep = [j for j, q in enumerate(batch['question']) if h.question_bucket(q) < 980]
                    stats['heldout_rows_excluded'] += len(batch['question']) - len(keep)
                    sources = tokenizer.encode_batch([batch['question'][j] for j in keep], add_special_tokens=False)
                    targets = tokenizer.encode_batch([batch['code'][j] for j in keep], add_special_tokens=False)
                    src, tgt = [], []
                    for s, t in zip(sources, targets):
                        if len(s.ids) + 1 <= cfg.max_source and len(t.ids) + 1 <= cfg.max_target:
                            src.append(s.ids + [h.EOS])
                            tgt.append(t.ids + [h.EOS])
                        else:
                            stats['overlength_rows_excluded'] += 1
                    if src:
                        writer.write_batch(pa.RecordBatch.from_pydict(
                            {'source_ids': src, 'target_ids': tgt,
                             'n_source': list(map(len, src)), 'n_target': list(map(len, tgt))}, schema=schema))
                        stats['train_rows'] += len(src)
                free = shutil.disk_usage(run).free
                print(json.dumps({'kind': 'data_progress', 'shard': i + 1, 'shards': shards,
                                  'rows': stats['train_rows'], 'free_disk_gb': round(free / 1e9, 2)}), flush=True)
                if free < 4_000_000_000:
                    raise RuntimeError('Insufficient free disk for resumable model checkpoints')
        os.replace(temporary, destination)
        h.write_json(part_manifest, {'signature': signature, **{key: stats[key] - previous[key] for key in previous}})
    stats['arrow_bytes'] = sum((token_dir / f'{i:05d}.arrow').stat().st_size for i in range(shards))
    h.write_json(manifest_path, stats)
    return concatenate_datasets([Dataset.from_file(str(token_dir / f'{i:05d}.arrow')) for i in range(shards)])


def export_submission(checkpoint, val, exports, question_path):
    model, tokenizer, cfg, device = h.load_inference(checkpoint)
    references, questions_val = list(val['code']), list(val['question'])
    experiments = []
    for limit in [128, 192, 256]:
        begin = time.perf_counter()
        predictions, diagnostics = h.predict(model, tokenizer, questions_val, cfg, device,
                                             batch_size=128, max_new_tokens=limit)
        result = {'limit': limit, 'seconds_h100': time.perf_counter() - begin,
                  **compare(predictions, references), **diagnostics}
        experiments.append(result)
        print(json.dumps({'kind': 'final_decoding_experiment', **result}), flush=True)
    best_accuracy = max(x['functional_accuracy'] for x in experiments)

    selected = min((x for x in experiments if x['functional_accuracy'] >= best_accuracy - 0.0025),
                   key=lambda x: x['limit'])
    limit = selected['limit']
    h.write_json(exports / 'decoding_experiments_130m.json', experiments)
    questions = [json.loads(line)['question'] for line in question_path.read_text().splitlines()]
    h.synchronize(device)
    begin = time.perf_counter()
    predictions, diagnostics = h.predict(model, tokenizer, questions, cfg, device,
                                         batch_size=128, max_new_tokens=limit)
    h.synchronize(device)
    seconds = time.perf_counter() - begin
    h.export_submission(predictions, exports / 'submission_130m.jsonl')
    meta = h.read_json(checkpoint / 'training_meta.json')
    info = {'parameters': PARAMETERS, 'checkpoint_step': meta['step'], 'max_new_tokens': limit,
            'validation_functional_accuracy': selected['functional_accuracy'],
            'reference_eligible': selected['reference_eligible'], 'official_pass_at_1': None,
            'generation_seconds_h100': seconds, 'gpu': torch.cuda.get_device_name(),
            't4_measured': False, 'required_t4_max_seconds': 180,
            'question_source': 'official_hf_test_in_parquet_order', 'original_bot_order_verified': False,
            'questions_sha256': h.file_hash(question_path),
            'submission_sha256': h.file_hash(exports / 'submission_130m.jsonl'), **diagnostics}
    h.write_json(exports / 'submission_130m_info.json', info)
    h.write_json(checkpoint / 'inference_config.json', {'max_new_tokens': limit, 'batch_size': 128,
                 'expected_rows': 1919, 'max_source': cfg.max_source, 'max_target': cfg.max_target})
    with zipfile.ZipFile(exports / 'checkpoint_130m.zip', 'w', compression=zipfile.ZIP_STORED) as archive:
        for name in ['config.json', 'generation_config.json', 'model.safetensors', 'tokenizer.json', 'training_meta.json', 'inference_config.json']:
            archive.write(checkpoint / name, 'best/' + name)
    h.write_json(exports / 'completed_130m.json', info)
    print('TRAINING_AND_SUBMISSION_COMPLETED', json.dumps(info), flush=True)
