"""Run 130M continuation in a separate directory without changing old runs."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PARENT = Path.home() / 'hse_hw2/runs/h100_130m_01'
BASELINE = Path.home() / 'hse_hw2/runs/h100_77m_baseline_01'
DEPENDENCIES = Path.home() / 'hse_hw2/dependencies/py311_v1/lib/python3.11/site-packages'


def status(phase, **values):
    record = {'phase': phase, 'updated_unix': time.time(), 'parameters': 130183936, **values}
    temporary = ROOT / 'worker_status.tmp.json'
    temporary.write_text(json.dumps(record, indent=2))
    temporary.replace(ROOT / 'worker_status.json')
    print(json.dumps(record), flush=True)


def main():
    os.chdir(ROOT)
    if not (PARENT / 'best/model.safetensors').is_file():
        raise FileNotFoundError('Original 130M best checkpoint is missing')
    if not (BASELINE / 'val_arrow/dataset_info.json').is_file():
        raise FileNotFoundError('Original validation data is missing')
    minimum = 2_000_000_000 if (ROOT / 'run/last.pt').is_file() else 5_500_000_000
    if shutil.disk_usage(ROOT).free < minimum:
        raise RuntimeError('Insufficient checkpoint disk space; no old files were removed')
    os.environ.update(PYTHONPATH=str(DEPENDENCIES) + os.pathsep + str(ROOT),
                      HF_HUB_DISABLE_XET='1', HF_HUB_DISABLE_IMPLICIT_TOKEN='1',
                      HF_ENDPOINT='https://huggingface.artifactory.s.o3.ru/artifactory/api/huggingfaceml/huggingface-remote',
                      HF_HOME=str(ROOT / 'hf_cache'), HF_HUB_DOWNLOAD_TIMEOUT='120',
                      USE_TF='0', USE_FLAX='0', OMP_NUM_THREADS='8',
                      RAYON_NUM_THREADS='16', TOKENIZERS_PARALLELISM='true')
    source_root = Path('/tmp/hw2_130m_v2_raw')
    raw = source_root / 'data/train'
    raw.mkdir(parents=True, exist_ok=True)
    inherited = []
    for i in range(60):
        name = f'part-{i:05d}.parquet'
        destination = raw / name
        candidates = [Path('/tmp/hse_hw2_data/data/train') / name,
                      Path('/tmp/codegen107_user/raw_train') / name,
                      Path('/tmp/codegen107_user/downloads/data/train') / name]
        if not destination.exists():
            source = next((p for p in candidates if p.is_file()), None)
            if source is not None:
                destination.symlink_to(source.resolve())
        if destination.exists():
            inherited.append(name)
    (ROOT / 'shared_public_raw.json').write_text(json.dumps({'revision': 'b2724689ff079e9c22efd548fe134bfb29036dbb',
                    'files_reused': inherited, 'mode': 'read_only_symlinks',
                    'missing_shards': 'download_pinned_revision_to_separate_tmp_storage'}, indent=2))
    status('preparing_and_training', steps_max=60000, learning_rate=8e-5,
           parent_checkpoint_step=38000, shards=60, disk_free_gb=shutil.disk_usage(ROOT).free / 1e9)
    command = [sys.executable, '-u', str(ROOT / 'train_new.py'), '--parent-run', str(PARENT),
               '--validation', str(BASELINE / 'val_arrow'), '--source-dir', str(source_root),
               '--questions', str(ROOT / 'delivery/questions_used.jsonl'),
               '--run', str(ROOT / 'run'), '--exports', str(ROOT / 'exports'),
               '--steps', '60000', '--lr', '0.00008', '--max-hours', '4']
    subprocess.run(command, cwd=ROOT, env=os.environ.copy(), check=True, timeout=7 * 3600)
    summary = json.loads((ROOT / 'exports/continuation_summary.json').read_text())
    status('completed', **summary)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        status('failed', error_type=type(error).__name__)
        raise
