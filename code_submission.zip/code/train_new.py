"""Continue the user's scratch-trained 130M model on all official train shards."""
import argparse
from dataclasses import asdict, replace
import gc
import json
import math
from pathlib import Path
import random
import time
import os

import torch
from datasets import load_from_disk
from tokenizers import Tokenizer
from transformers import BartForConditionalGeneration, get_cosine_schedule_with_warmup

import hw2_core as h
from safe_numeric import compare
from data_and_export import prepare_training, export_submission, PARAMETERS


def inherit_token_shards(parent, run, tokenizer_hash, cfg):
    manifest = h.read_json(parent / 'data_manifest.json')
    old = manifest['signature']
    if old != {'dataset': h.DATASET, 'revision': h.REVISION, 'shards': 30,
               'tokenizer_sha256': tokenizer_hash, 'max_source': cfg.max_source,
               'max_target': cfg.max_target, 'split': 'normalized_question_sha256_mod_1000_lt_980'}:
        raise ValueError('Parent token cache settings differ')
    signature = {**old, 'shards': 60}
    target = run / 'train_token_shards'
    target.mkdir(exist_ok=True)
    inherited = []
    for i in range(30):
        source = parent / 'train_token_shards' / f'{i:05d}.arrow'
        part = parent / 'train_token_shards' / f'{i:05d}.json'
        if not source.is_file() or not part.is_file():
            continue
        info = h.read_json(part)
        if info['signature'] != old:
            raise ValueError('Parent per-shard signature differs')
        destination = target / source.name
        if not destination.exists():
            destination.symlink_to(source.resolve())
            h.write_json(target / part.name, {**info, 'signature': signature,
                         'inherited_from': str(source), 'shared_read_only': True})
        inherited.append(i)
    h.write_json(run / 'inherited_token_shards.json', {'indices': inherited,
                 'parent': str(parent), 'parent_modified': False})


def lineage_meta(run, parent_meta, cfg, step, event):
    path = run / 'best/training_meta.json'
    meta = h.read_json(path)
    meta.update(initialization='continued_own_scratch_trained_checkpoint',
                parent_checkpoint_step=parent_meta['step'],
                parent_initialization=parent_meta['initialization'],
                additional_training_step=step,
                lineage_total_steps=parent_meta['step'] + step,
                external_pretrained_weights=False, extra_training_targets=False,
                best_validation=event, tokenizer_source='original_baseline_train_only')
    h.write_json(path, meta)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent-run', type=Path, required=True)
    parser.add_argument('--validation', type=Path, required=True)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--questions', type=Path, required=True)
    parser.add_argument('--run', type=Path, default=Path('run'))
    parser.add_argument('--exports', type=Path, default=Path('exports'))
    parser.add_argument('--steps', type=int, default=60000)
    parser.add_argument('--lr', type=float, default=8e-5)
    parser.add_argument('--max-hours', type=float, default=4)
    args = parser.parse_args()
    if args.steps < 1 or not 0 < args.lr <= 1e-4 or args.max_hours <= 0:
        raise ValueError('Invalid continuation budget')
    parent = args.parent_run.resolve()
    run, exports = args.run.resolve(), args.exports.resolve()
    if run == parent or parent in run.parents or exports == parent or parent in exports.parents:
        raise ValueError('Use an independent directory outside the parent run')
    run.mkdir(parents=True, exist_ok=True)
    exports.mkdir(parents=True, exist_ok=True)
    parent_meta = h.read_json(parent / 'best/training_meta.json')
    if parent_meta['parameters'] != PARAMETERS or parent_meta['initialization'] != 'random':
        raise ValueError('Expected the original scratch-trained 130M parent')
    cfg = replace(h.Config(**parent_meta['config']), steps=args.steps, lr=args.lr,
                  warmup=min(500, args.steps // 10), shard_count=60, max_rows=12_000_000,
                  eval_every=1000, save_every=1000, log_every=100)
    if (run / 'config.json').exists() and h.read_json(run / 'config.json') != asdict(cfg):
        raise ValueError('Run config changed; choose a new directory')
    h.write_json(run / 'config.json', asdict(cfg))
    (run / 'tokenizer.json').write_bytes((parent / 'tokenizer.json').read_bytes())
    tokenizer_hash = h.file_hash(run / 'tokenizer.json')
    if tokenizer_hash != '30c8aefc73bfab0ae91d1ebf95561abab1b6a69abf4fc3e8a460424a4c7d9d6c':
        raise ValueError('Unexpected parent tokenizer')
    tok = Tokenizer.from_file(str(run / 'tokenizer.json'))
    assert h.count_parameters(cfg, tok.get_vocab_size()) == PARAMETERS
    inherit_token_shards(parent, run, tokenizer_hash, cfg)
    train_ds = prepare_training(run, tok, 60, cfg, args.source_dir.resolve())
    val = load_from_disk(str(args.validation.resolve()))
    if len(val) != 1024 or any(h.question_bucket(q) < 980 for q in val['question']):
        raise ValueError('Expected the unchanged question-group validation split')
    h.seed_all(cfg.seed)
    torch.set_num_threads(8)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU required')
    device = torch.device('cuda:0')
    free, _ = torch.cuda.mem_get_info()
    if free < 28 * 1024**3:
        raise RuntimeError('Need at least 28 GiB free GPU memory')
    model = BartForConditionalGeneration.from_pretrained(
        str(parent / 'best'), local_files_only=True, torch_dtype=torch.float32,
        attn_implementation='sdpa').to(device)
    assert sum(p.numel() for p in model.parameters()) == PARAMETERS
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr,
                                 weight_decay=cfg.weight_decay, fused=True)
    scheduler = get_cosine_schedule_with_warmup(optimizer, cfg.warmup, cfg.steps)
    questions, references = list(val['question']), list(val['code'])

    def evaluate(step, kind='validation'):
        scores = h.evaluate_loss(model, val, cfg, device)
        predictions, diagnostics = h.predict(model, tok, questions, cfg, device,
                                             batch_size=128, max_new_tokens=192)
        scores.update(compare(predictions, references))
        event = {'kind': kind, 'step': step, **scores, **diagnostics}
        h.append_event(run / 'metrics.jsonl', event)
        print(json.dumps(event), flush=True)
        model.train()
        return event, predictions

    start, epoch, position = 0, 0, 0
    prior_elapsed = 0
    if (run / 'last.pt').exists():
        state = torch.load(run / 'last.pt', map_location='cpu', weights_only=True)
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        scheduler.load_state_dict(state['scheduler'])
        start, epoch, position = state['step'], state['epoch'], state['next_batch']
        best_accuracy, best_loss = state['best_accuracy'], state['best_loss']
        baseline_accuracy = state['baseline_accuracy']
        prior_elapsed = state['elapsed_seconds']
        torch.set_rng_state(state['torch_rng'])
        torch.cuda.set_rng_state_all(state['cuda_rng'])
        random.setstate(state['python_rng'])
        del state
    else:
        event, predictions = evaluate(0, 'parent_baseline')
        best_accuracy, best_loss = event['functional_accuracy'], event['val_loss']
        baseline_accuracy = best_accuracy
        h.save_inference(model, tok, run / 'best', cfg, 0)
        lineage_meta(run, parent_meta, cfg, 0, event)
        h.write_predictions(run / 'validation_best.jsonl', questions, predictions)
    h.write_json(run / 'environment.json', {'parameters': PARAMETERS,
                 'gpu': torch.cuda.get_device_name(), 'torch': str(torch.__version__),
                 'train_rows': len(train_ds), 'val_rows': len(val),
                 'parent_checkpoint_step': parent_meta['step'], 'precision': str(h.precision(device))})
    batches = h.BatchStream(train_ds, cfg, device, epoch, position)
    started = time.perf_counter()
    model.train()
    output = batch = None
    print('TRAINING_STARTED', json.dumps({'steps': cfg.steps, 'start_step': start,
          'parameters': PARAMETERS, 'train_rows': len(train_ds), 'lr': cfg.lr}), flush=True)
    for step in range(start + 1, cfg.steps + 1):
        begin = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss_value = 0.0
        for _ in range(cfg.accumulation):
            batch = next(batches)
            with h.autocast(device):
                output = model(**batch, use_cache=False)
                loss = output.loss / cfg.accumulation
            if not torch.isfinite(loss):
                raise FloatingPointError('Non-finite loss; resumable checkpoint retained')
            loss.backward()
            loss_value += float(loss.detach())
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
        optimizer.step()
        scheduler.step()
        h.synchronize(device)
        seconds = time.perf_counter() - begin
        elapsed = prior_elapsed + time.perf_counter() - started
        stop = step == cfg.steps or elapsed >= args.max_hours * 3600
        if step == start + 1 or step % cfg.log_every == 0:
            event = {'kind': 'train', 'step': step, 'train_loss': loss_value,
                     'lr': scheduler.get_last_lr()[0], 'grad_norm': float(grad_norm),
                     'step_seconds': seconds, 'elapsed_seconds': elapsed,
                     'minutes_train_left_estimate': (cfg.steps - step) * seconds / 60}
            h.append_event(run / 'metrics.jsonl', event)
            print(json.dumps(event), flush=True)
        if step % cfg.eval_every == 0 or stop:
            event, predictions = evaluate(step)
            accuracy = event['functional_accuracy']
            if accuracy > best_accuracy or accuracy == best_accuracy and event['val_loss'] < best_loss:
                best_accuracy, best_loss = accuracy, event['val_loss']
                h.save_inference(model, tok, run / 'best', cfg, step)
                lineage_meta(run, parent_meta, cfg, step, event)
                h.write_predictions(run / 'validation_best.jsonl', questions, predictions)
        if step % cfg.save_every == 0 or stop:
            state = {'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
                     'scheduler': scheduler.state_dict(), 'step': step,
                     'best_accuracy': best_accuracy, 'best_loss': best_loss,
                     'baseline_accuracy': baseline_accuracy, 'epoch': batches.epoch,
                     'next_batch': batches.next_batch, 'torch_rng': torch.get_rng_state(),
                     'python_rng': random.getstate(), 'cuda_rng': torch.cuda.get_rng_state_all(),
                     'elapsed_seconds': prior_elapsed + time.perf_counter() - started}
            torch.save(state, run / 'last.tmp.pt')
            os.replace(run / 'last.tmp.pt', run / 'last.pt')
            del state
        if stop:
            break
    summary = {'additional_steps': step, 'best_local_accuracy': best_accuracy,
               'parent_local_accuracy': baseline_accuracy,
               'local_improvement': best_accuracy - baseline_accuracy,
               'official_pass_at_1': None, 't4_measured': False}
    h.write_json(run / 'completed.json', summary)
    del model, optimizer, scheduler, output, batch
    gc.collect()
    torch.cuda.empty_cache()
    export_submission(run / 'best', val, exports, args.questions.resolve())
    h.write_json(exports / 'continuation_summary.json', summary)


if __name__ == '__main__':
    main()
