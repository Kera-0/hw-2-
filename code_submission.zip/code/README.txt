Итоговая модель: 130M V2, checkpoint после 50 000 шагов продолжения.
train_new.py — продолжение собственного checkpoint; data_and_export.py — данные и экспорт;
hw2_core.py — модель, токенизатор и общие функции; server_worker.py — запуск на H100;
inference_130m.py и benchmark_130m.py — полный замер на T4.
artifacts/v2 — конфиги, результаты и полный лог метрик; artifacts/first_130m — первый запуск.
history/baseline_77m и history/first_130m — использованный ранее код и notebook.
history/code107m — независимый неудачный эксперимент, не использован в итоговой модели.
Внешние предобученные веса и дополнительные таргеты не используются.

train_new.py принимает пути --parent-run, --validation, --source-dir, --questions,
--run, --exports. Нужен лучший checkpoint первой 130M; он сохранён отдельно
в исходном комплекте hw2_130m_final.zip. Для проверки на T4 повторять обучение не нужно.
