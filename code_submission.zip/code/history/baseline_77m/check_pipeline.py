"""CPU integration check using ONLY a small sample of the official training dataset.

Run: python check_pipeline.py --official-sample /path/to/first-rows.json --work-dir /tmp/hw2-check
The first-rows file is the response of the official HF dataset viewer; no extra training corpus.
"""
import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from datasets import Dataset, concatenate_datasets

import hw2_core as h


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--official-sample", required=True)
    parser.add_argument("--work-dir", required=True)
    args = parser.parse_args()
    root = Path(args.work_dir)
    root.mkdir(parents=True, exist_ok=True)
    production_parameters = h.count_parameters(h.Config(), 8192)
    assert production_parameters == 77_585_664
    assert 70_000_000 <= h.count_parameters(h.Config(), 256) <= 256_000_000
    sample_path = Path(args.official_sample)
    if sample_path.suffix == ".parquet":
        raw = Dataset.from_parquet(str(sample_path)).select(range(1024))
    else:
        rows = json.loads(sample_path.read_text())["rows"]
        raw = Dataset.from_list([row["row"] for row in rows])

    raw = concatenate_datasets([raw, raw.select(range(10))])
    cfg = replace(h.Config(), max_rows=len(raw), val_size=20, tokenizer_rows=len(raw),
                  vocab_size=512, max_source=256, max_target=512,
                  d_model=32, encoder_layers=1, decoder_layers=1, heads=2, ffn=64,
                  batch_size=4, accumulation=2, steps=40, warmup=2,
                  eval_every=20, save_every=20, log_every=20, dropout=0.0)
    h.seed_all(cfg.seed)
    torch.set_num_threads(2)
    train_ds, val_ds, tok, stats = h.prepare_data(raw, root / "run", cfg)
    assert not set(train_ds["question"]) & set(val_ds["question"])
    reloaded_train, reloaded_val, tok2, stats2 = h.prepare_data(raw, root / "run", cfg)
    assert stats == stats2 and train_ds[:5] == reloaded_train[:5]
    for code in raw["code"]:
        assert tok.decode(tok.encode(code).ids) == code
    assert tok.to_str() == tok2.to_str()
    model = h.make_model(cfg, tok.get_vocab_size())
    assert h.count_parameters(cfg, tok.get_vocab_size()) == sum(p.numel() for p in model.parameters())
    batch = h.Collator(cfg.max_source, cfg.max_target)([train_ds[i] for i in range(4)])
    model.eval()
    with torch.no_grad():
        out = model(**batch, use_cache=False)
        shifted = model.prepare_decoder_input_ids_from_labels(batch["labels"])
        explicit = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"],
                         decoder_input_ids=shifted, use_cache=False)
    assert torch.allclose(out.logits, explicit.logits)
    assert (shifted[:, 0] == h.BOS).all()
    assert batch["labels"].eq(-100).any(), "Need padding for a meaningful ignore-index check"
    manual_loss = torch.nn.functional.cross_entropy(out.logits.flatten(0, 1), batch["labels"].flatten(),
                                                    ignore_index=-100)
    assert torch.allclose(out.loss, manual_loss)
    h.save_inference(model, tok, root / "initial", cfg, 0)
    loaded, tok2, cfg2, device = h.load_inference(root / "initial")
    loaded.eval()
    with torch.no_grad():
        assert torch.allclose(out.logits, loaded(**batch, use_cache=False).logits)
        uncached = loaded.generate(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"],
                                  max_new_tokens=8, use_cache=False, forced_eos_token_id=None)
        cached = loaded.generate(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"],
                                max_new_tokens=8, use_cache=True, forced_eos_token_id=None)
        assert torch.equal(uncached, cached), "KV-cache must preserve greedy decoding"
    initial_loss = h.evaluate_loss(model, train_ds.select(range(8)), cfg, device)["val_loss"]
    tiny = train_ds.select(range(8))
    trained = h.train(tiny, val_ds, tok, root / "run", cfg, allow_cpu=True)
    final_loss = h.evaluate_loss(trained, tiny, cfg, device)["val_loss"]
    assert final_loss < initial_loss, (initial_loss, final_loss)

    repeated = h.train(tiny, val_ds, tok, root / "run", cfg, allow_cpu=True)
    assert all(torch.equal(a, b) for a, b in zip(trained.parameters(), repeated.parameters()))

    resume_cfg = replace(cfg, steps=6, eval_every=3, save_every=3, dropout=0.1)
    uninterrupted = h.train(tiny, val_ds, tok, root / "continuous", resume_cfg, allow_cpu=True)
    h.train(tiny, val_ds, tok, root / "resumed", resume_cfg, allow_cpu=True, stop_after=3)
    resumed = h.train(tiny, val_ds, tok, root / "resumed", resume_cfg, allow_cpu=True)
    assert all(torch.equal(a, b) for a, b in zip(uninterrupted.parameters(), resumed.parameters())), "Resume RNG mismatch"
    best, tokenizer, saved_cfg, device = h.load_inference(root / "run/best")
    questions = list(raw["question"][:5])
    batched, diag = h.predict(best, tokenizer, questions, saved_cfg, device, batch_size=3, max_new_tokens=12)
    single = [h.predict(best, tokenizer, [q], saved_cfg, device, batch_size=1, max_new_tokens=12)[0][0]
              for q in questions]
    assert batched == single, "Sorting/batching must restore original question order"
    file = root / "submission.jsonl"

    expected = [batched[i % len(batched)] for i in range(1919)]
    h.export_submission(expected, file)
    records = [json.loads(line) for line in file.read_text().splitlines()]
    assert len(records) == 1919 and [r["code"] for r in records] == expected
    assert all(set(r) == {"code"} for r in records)
    try:
        h.export_submission(expected[:-1], root / "bad.jsonl")
    except ValueError:
        pass
    else:
        raise AssertionError("Submission with wrong row count accepted")
    h.render_report(root / "run", root / "report.html")
    summary = {"status": "passed", "official_sample_rows": len(raw), "train_rows": len(train_ds),
               "production_parameters_at_vocab_8192": production_parameters,
               "val_rows": len(val_ds), "initial_tiny_train_loss": initial_loss,
               "final_tiny_train_loss": final_loss,
               "checks": ["group split and Arrow cache", "loss masks and decoder shift",
                          "whitespace roundtrip", "checkpoint logits", "KV cache equivalence",
                          "training loss decreases", "optimizer/RNG resume", "original output order",
                          "1919-row bot format", "wrong row count rejected", "report export"]}
    h.write_json(root / "check_results.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
