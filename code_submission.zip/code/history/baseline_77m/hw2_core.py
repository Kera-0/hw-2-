"""HW2: train-only tokenizer, randomly initialized encoder-decoder, reproducible data path.

No pretrained weights, additional training data, synthetic targets or code execution.
"""
from __future__ import annotations

import ast
import contextlib
import hashlib
import html
import json
import math
import os
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
from datasets import Dataset, load_dataset, load_from_disk
from huggingface_hub import hf_hub_download
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers
from torch.utils.data import DataLoader
from transformers import BartConfig, BartForConditionalGeneration, get_cosine_schedule_with_warmup

DATASET = "SlavaYus/tinysms_qa_12m"
REVISION = "b2724689ff079e9c22efd548fe134bfb29036dbb"
PAD, UNK, BOS, EOS = 0, 1, 2, 3
SPECIALS = ["<pad>", "<unk>", "<s>", "</s>"]


@dataclass
class Config:
    seed: int = 42
    shard_count: int = 6
    max_rows: int = 1_000_000
    val_size: int = 1024
    tokenizer_rows: int = 50_000
    vocab_size: int = 8192
    max_source: int = 192
    max_target: int = 256
    d_model: int = 768
    encoder_layers: int = 6
    decoder_layers: int = 3
    heads: int = 12
    ffn: int = 3072
    dropout: float = 0.1
    batch_size: int = 64
    accumulation: int = 4
    steps: int = 10_000
    warmup: int = 500
    lr: float = 3e-4
    weight_decay: float = 0.01
    eval_every: int = 500
    save_every: int = 250
    log_every: int = 25
    workers: int = 0
    tokenization_processes: int = 1
    bucket_by_length: bool = True


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def question_bucket(question):

    key = " ".join(question.casefold().split()).encode("utf-8")
    return int.from_bytes(hashlib.sha256(key).digest()[:8], "big") % 1000


def download_files(root, shard_count=6, include_train=True):
    if not 1 <= shard_count <= 60:
        raise ValueError("shard_count must be between 1 and 60")
    root = Path(root)
    names = ["data/test/test.parquet"]
    if include_train:
        names += [f"data/train/part-{i:05d}.parquet" for i in range(shard_count)]
    for name in names:
        hf_hub_download(DATASET, name, repo_type="dataset", revision=REVISION,
                        local_dir=str(root), etag_timeout=120)
    write_json(root / "download_manifest.json", {
        "dataset": DATASET, "revision": REVISION,
        "files": {name: file_hash(root / name) for name in names},
    })
    return root


def load_raw(root, cfg):
    root = Path(root)
    paths = [root / f"data/train/part-{i:05d}.parquet" for i in range(cfg.shard_count)]
    missing = [str(p) for p in paths if not p.is_file()]
    if missing:
        raise FileNotFoundError(f"Download/upload data first. Missing: {missing[:3]}")
    raw = load_dataset("parquet", data_files=[str(p) for p in paths], split="train")
    if not {"question", "code"} <= set(raw.column_names):
        raise ValueError("Expected official train schema: question, code")
    return raw.shuffle(seed=cfg.seed).select(range(min(cfg.max_rows, len(raw))))


def train_tokenizer(train, path, cfg):
    tokenizer = Tokenizer(models.BPE(unk_token=SPECIALS[UNK]))
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tokenizer.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(vocab_size=cfg.vocab_size, min_frequency=2,
                                 special_tokens=SPECIALS,
                                 initial_alphabet=pre_tokenizers.ByteLevel.alphabet())

    def texts():
        for row in train.select(range(min(cfg.tokenizer_rows, len(train)))):
            yield row["question"]
            yield row["code"]

    tokenizer.train_from_iterator(texts(), trainer)
    tokenizer.save(str(path))
    assert [tokenizer.token_to_id(x) for x in SPECIALS] == [PAD, UNK, BOS, EOS]
    return tokenizer


def tokenize_batch(batch, tokenizer_path):

    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    questions = tokenizer.encode_batch(batch["question"], add_special_tokens=False)
    codes = tokenizer.encode_batch(batch["code"], add_special_tokens=False)
    return {"source_ids": [x.ids + [EOS] for x in questions],
            "target_ids": [x.ids + [EOS] for x in codes],
            "n_source": [len(x.ids) + 1 for x in questions],
            "n_target": [len(x.ids) + 1 for x in codes]}


def prepare_data(raw, run_dir, cfg):
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    signature = {k: asdict(cfg)[k] for k in [
        "seed", "val_size", "tokenizer_rows", "vocab_size", "max_source", "max_target"]}
    signature.update(raw_fingerprint=raw._fingerprint, dataset_revision=REVISION)
    manifest = run_dir / "data_manifest.json"
    if manifest.exists():
        saved = read_json(manifest)
        if saved["signature"] != signature:
            raise ValueError("Data/tokenizer settings changed. Use a NEW run directory.")
        if file_hash(run_dir / "tokenizer.json") != saved["tokenizer_sha256"]:
            raise ValueError("Cached tokenizer changed. Use a new run directory.")
        return (load_from_disk(str(run_dir / "train_arrow")),
                load_from_disk(str(run_dir / "val_arrow")),
                Tokenizer.from_file(str(run_dir / "tokenizer.json")), saved)
    grouped = raw.map(lambda b: {"bucket": [question_bucket(q) for q in b["question"]]},
                      batched=True, desc="Stable question-group split")
    train = grouped.filter(lambda b: [v < 980 for v in b["bucket"]], batched=True)
    val = grouped.filter(lambda b: [v >= 980 for v in b["bucket"]], batched=True)
    val = val.select(range(min(cfg.val_size, len(val))))
    if len(train) < cfg.batch_size or not len(val):
        raise ValueError("Not enough train/validation rows. Increase max_rows.")
    tokenizer_path = run_dir / "tokenizer.json"
    tokenizer = train_tokenizer(train, tokenizer_path, cfg)
    stats = {"raw_rows": len(raw), "split_train": len(train), "split_val": len(val)}
    result = []
    for name, ds in [("train", train), ("val", val)]:
        encoded = ds.map(tokenize_batch, batched=True, batch_size=2048,
                         fn_kwargs={"tokenizer_path": str(tokenizer_path)},
                         num_proc=cfg.tokenization_processes,
                         remove_columns=["bucket"], desc=f"Tokenize {name}")
        stats[name + "_length_quantiles"] = {
            key: np.quantile(encoded[key], [0.5, 0.9, 0.95, 0.99]).tolist()
            for key in ["n_source", "n_target"]}
        if name == "train":

            before = len(encoded)
            encoded = encoded.filter(
                lambda b: [s <= cfg.max_source and t <= cfg.max_target
                           for s, t in zip(b["n_source"], b["n_target"])], batched=True)
            stats["train_dropped_overlength_fraction"] = 1 - len(encoded) / before
        else:

            stats["val_overlength_fraction"] = float(np.mean(
                [s > cfg.max_source or t > cfg.max_target
                 for s, t in zip(encoded["n_source"], encoded["n_target"])]))
        encoded.save_to_disk(str(run_dir / f"{name}_arrow"))
        result.append(encoded)
        stats[name + "_rows"] = len(encoded)
    if len(result[0]) < cfg.batch_size:
        raise ValueError("Too few examples after length filtering; increase length limits.")
    stats.update(signature=signature, tokenizer_sha256=file_hash(tokenizer_path))
    write_json(manifest, stats)
    return (*result, tokenizer, stats)


class Collator:
    def __init__(self, max_source=192, max_target=256):
        self.max_source, self.max_target = max_source, max_target

    def __call__(self, rows):
        sources = [r["source_ids"][:self.max_source - 1] + [EOS]
                   if len(r["source_ids"]) > self.max_source else r["source_ids"] for r in rows]
        targets = [r["target_ids"] for r in rows]
        source_len = math.ceil(max(map(len, sources)) / 8) * 8
        target_len = math.ceil(max(map(len, targets)) / 8) * 8
        if target_len > self.max_target:
            raise ValueError("Overlength target must be excluded from teacher-forced validation.")
        ids = torch.full((len(rows), source_len), PAD, dtype=torch.long)
        labels = torch.full((len(rows), target_len), -100, dtype=torch.long)
        for i, (src, tgt) in enumerate(zip(sources, targets)):
            ids[i, :len(src)] = torch.tensor(src)
            labels[i, :len(tgt)] = torch.tensor(tgt)
        return {"input_ids": ids, "attention_mask": ids.ne(PAD).long(), "labels": labels}


def make_model(cfg, vocab_size):
    config = BartConfig(
        vocab_size=vocab_size, d_model=cfg.d_model,
        encoder_layers=cfg.encoder_layers, decoder_layers=cfg.decoder_layers,
        encoder_attention_heads=cfg.heads, decoder_attention_heads=cfg.heads,
        encoder_ffn_dim=cfg.ffn, decoder_ffn_dim=cfg.ffn,
        max_position_embeddings=max(cfg.max_source, cfg.max_target) + 8,
        pad_token_id=PAD, unk_token_id=UNK, bos_token_id=BOS, eos_token_id=EOS,
        decoder_start_token_id=BOS, forced_eos_token_id=None,
        dropout=cfg.dropout, attention_dropout=0.0, use_cache=False,
    )
    config._attn_implementation = "sdpa"

    return BartForConditionalGeneration(config)


def count_parameters(cfg, vocab_size):

    with torch.device("meta"):
        model = make_model(cfg, vocab_size)
    return sum(parameter.numel() for parameter in model.parameters())


def precision(device):
    if device.type != "cuda":
        return torch.float32
    return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16


def autocast(device):
    return (torch.autocast("cuda", dtype=precision(device))
            if device.type == "cuda" else contextlib.nullcontext())


def batch_indices(ds, cfg, epoch):
    indices = torch.randperm(len(ds), generator=torch.Generator().manual_seed(cfg.seed + epoch)).tolist()
    if cfg.bucket_by_length:
        lengths = np.asarray(ds["n_source"]) + np.asarray(ds["n_target"])
        chunk = cfg.batch_size * 32
        indices = [i for start in range(0, len(indices), chunk)
                   for i in sorted(indices[start:start + chunk], key=lambda j: lengths[j])]
    batches = [indices[i:i + cfg.batch_size] for i in range(0, len(indices), cfg.batch_size)]
    random.Random(cfg.seed + epoch).shuffle(batches)
    return batches


class BatchStream:
    def __init__(self, dataset, cfg, device, epoch=0, next_batch=0):

        self.dataset = dataset.select_columns(["source_ids", "target_ids", "n_source", "n_target"])
        self.cfg, self.device = cfg, device
        self.epoch, self.next_batch = epoch, next_batch
        self.iterator = None

    def __next__(self):
        while True:
            if self.iterator is None:
                batches = batch_indices(self.dataset, self.cfg, self.epoch)
                loader = DataLoader(self.dataset, batch_sampler=batches[self.next_batch:],
                                    collate_fn=Collator(self.cfg.max_source, self.cfg.max_target),
                                    num_workers=self.cfg.workers,
                                    generator=torch.Generator().manual_seed(self.cfg.seed + self.epoch),
                                    pin_memory=self.device.type == "cuda")
                self.iterator = iter(loader)
            try:
                batch = next(self.iterator)
                self.next_batch += 1
                return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}
            except StopIteration:
                self.epoch += 1
                self.next_batch = 0
                self.iterator = None


def synchronize(device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


@torch.inference_mode()
def evaluate_loss(model, dataset, cfg, device):

    valid = dataset.filter(lambda r: r["n_target"] <= cfg.max_target)
    if not len(valid):
        raise ValueError("No validation targets fit the context.")
    loader = DataLoader(valid, batch_size=cfg.batch_size,
                        generator=torch.Generator().manual_seed(cfg.seed),
                        collate_fn=Collator(cfg.max_source, cfg.max_target))
    model.eval()
    total_loss, tokens, correct = 0.0, 0, 0
    for batch in loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        with autocast(device):
            out = model(**batch, use_cache=False)
        mask = batch["labels"].ne(-100)
        count = int(mask.sum())
        tokens += count
        total_loss += float(out.loss) * count
        correct += int(((out.logits.argmax(-1) == batch["labels"]) & mask).sum())
    model.train()
    return {"val_loss": total_loss / tokens, "val_token_accuracy": correct / tokens,
            "val_loss_rows": len(valid), "val_all_rows": len(dataset)}


def append_event(path, event):
    event = {"time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), **event}
    with open(path, "a", encoding="utf-8") as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + "\n")


def save_inference(model, tokenizer, directory, cfg, step):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(directory), safe_serialization=True)
    tokenizer.save(str(directory / "tokenizer.json"))
    write_json(directory / "training_meta.json", {"config": asdict(cfg), "step": step,
               "parameters": sum(p.numel() for p in model.parameters()),
               "dataset": DATASET, "revision": REVISION, "initialization": "random"})


def train(train_ds, val_ds, tokenizer, run_dir, cfg, resume=True, allow_cpu=False, stop_after=None):
    seed_all(cfg.seed)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type == "cpu" and not allow_cpu:
        raise RuntimeError("GPU required for real training. CPU is only for smoke testing.")
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    settings_path = run_dir / "config.json"
    settings = asdict(cfg)
    if settings_path.exists() and read_json(settings_path) != settings:
        raise ValueError("Run configuration changed. Use a new run directory (including changed step budget).")
    write_json(settings_path, settings)
    model = make_model(cfg, tokenizer.get_vocab_size()).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr,
                                 weight_decay=cfg.weight_decay, fused=device.type == "cuda")
    scheduler = get_cosine_schedule_with_warmup(optimizer, cfg.warmup, cfg.steps)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and precision(device) == torch.float16)
    state_path = run_dir / "last.pt"
    start, best, epoch, position = 0, float("inf"), 0, 0
    if resume and state_path.exists():
        state = torch.load(state_path, map_location="cpu", weights_only=True)
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        scaler.load_state_dict(state["scaler"])
        start, best = state["step"], state["best"]
        epoch, position = state["epoch"], state["next_batch"]
        torch.set_rng_state(state["torch_rng"])
        random.setstate(state["python_rng"])
        if device.type == "cuda" and state["cuda_rng"]:
            torch.cuda.set_rng_state_all(state["cuda_rng"])
        print(f"Resumed step {start}, epoch {epoch}, batch {position}")
    elif not resume and state_path.exists():
        raise ValueError("Existing run: resume it or choose a new directory.")
    batches = BatchStream(train_ds, cfg, device, epoch, position)
    model.train()
    count = sum(p.numel() for p in model.parameters())
    print(f"Device={device}; precision={precision(device)}; parameters={count:,}")
    print(f"Effective batch={cfg.batch_size * cfg.accumulation}; planned optimizer steps={cfg.steps}")
    write_json(run_dir / "environment.json", {"torch": str(torch.__version__),
               "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else "CPU",
               "parameters": count, "precision": str(precision(device)),
               "torch_cpu_threads": torch.get_num_threads(),
               "cuda": torch.version.cuda,
               "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory
               if device.type == "cuda" else None})

    def checkpoint(step):
        state = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                 "scheduler": scheduler.state_dict(), "scaler": scaler.state_dict(),
                 "step": step, "best": best, "epoch": batches.epoch,
                 "next_batch": batches.next_batch, "torch_rng": torch.get_rng_state(),
                 "python_rng": random.getstate(),
                 "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else []}
        temporary = run_dir / "last.tmp.pt"
        torch.save(state, temporary)
        os.replace(temporary, state_path)

    last_step = min(cfg.steps, stop_after or cfg.steps)
    for step in range(start + 1, last_step + 1):
        synchronize(device)
        begin = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss_value, target_tokens, examples, padded_tokens, fetch_seconds = 0.0, 0, 0, 0, 0.0
        for _ in range(cfg.accumulation):
            fetch_begin = time.perf_counter()
            batch = next(batches)
            fetch_seconds += time.perf_counter() - fetch_begin
            with autocast(device):
                output = model(**batch, use_cache=False)
                loss = output.loss / cfg.accumulation
            if not torch.isfinite(loss):
                raise FloatingPointError("Non-finite loss. Previous checkpoint remains resumable.")
            scaler.scale(loss).backward()
            loss_value += float(loss.detach())
            target_tokens += int(batch["labels"].ne(-100).sum())
            examples += batch["input_ids"].shape[0]
            padded_tokens += batch["labels"].numel()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        previous_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        if scaler.get_scale() >= previous_scale:
            scheduler.step()
        synchronize(device)
        elapsed = time.perf_counter() - begin
        if step == 1 or step % cfg.log_every == 0:
            event = {"kind": "train", "step": step, "train_loss": loss_value,
                     "lr": scheduler.get_last_lr()[0], "step_seconds": elapsed,
                     "examples_per_second": examples / elapsed,
                     "batch_fetch_seconds": fetch_seconds,
                     "target_tokens_per_second": target_tokens / elapsed,
                     "target_padding_fraction": 1 - target_tokens / padded_tokens,
                     "estimated_train_hours_left": (cfg.steps - step) * elapsed / 3600}
            append_event(run_dir / "metrics.jsonl", event)
            print(json.dumps(event, ensure_ascii=False))
        if step % cfg.eval_every == 0 or step == last_step:
            scores = evaluate_loss(model, val_ds, cfg, device)
            append_event(run_dir / "metrics.jsonl", {"kind": "validation", "step": step, **scores})
            print(scores)
            if scores["val_loss"] < best:
                best = scores["val_loss"]
                save_inference(model, tokenizer, run_dir / "best", cfg, step)
        if step % cfg.save_every == 0 or step == last_step:
            checkpoint(step)
    return model


def load_inference(directory, device=None):
    directory = Path(directory)
    if not (directory / "model.safetensors").is_file():
        raise FileNotFoundError("Provide a trained best/ directory with model.safetensors.")
    device = device or torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = BartForConditionalGeneration.from_pretrained(
        str(directory), local_files_only=True, attn_implementation="sdpa",
        torch_dtype=torch.float16 if device.type == "cuda" else torch.float32,
    ).to(device).eval()
    tokenizer = Tokenizer.from_file(str(directory / "tokenizer.json"))
    meta = read_json(directory / "training_meta.json")
    return model, tokenizer, Config(**meta["config"]), device


@torch.inference_mode()
def predict(model, tokenizer, questions, cfg, device, batch_size=64, max_new_tokens=None):
    limit = max_new_tokens or cfg.max_target
    if limit > cfg.max_target:
        raise ValueError("Generation limit exceeds training target context.")
    if not questions:
        return [], {"rows": 0, "source_clipped": 0, "no_eos": 0}
    sequences = [x.ids for x in tokenizer.encode_batch(questions, add_special_tokens=False)]
    clipped = sum(len(x) + 1 > cfg.max_source for x in sequences)
    sequences = [x[:cfg.max_source - 1] + [EOS] for x in sequences]
    order = sorted(range(len(sequences)), key=lambda i: len(sequences[i]))
    predictions, no_eos = [None] * len(sequences), 0
    model.eval()
    for start in range(0, len(order), batch_size):
        indices = order[start:start + batch_size]
        width = math.ceil(max(len(sequences[i]) for i in indices) / 8) * 8
        ids = torch.full((len(indices), width), PAD, dtype=torch.long, device=device)
        for j, index in enumerate(indices):
            ids[j, :len(sequences[index])] = torch.tensor(sequences[index], device=device)
        generated = model.generate(
            input_ids=ids, attention_mask=ids.ne(PAD).long(),
            do_sample=False, num_beams=1, use_cache=True,
            max_new_tokens=limit, forced_eos_token_id=None,
            suppress_tokens=[PAD, UNK, BOS],
        ).cpu().tolist()
        for index, tokens in zip(indices, generated):
            no_eos += EOS not in tokens[1:]
            predictions[index] = tokenizer.decode(tokens, skip_special_tokens=True)
    return predictions, {"rows": len(questions), "source_clipped": clipped, "no_eos": no_eos}


def syntax_ok(code):
    try:
        parsed = ast.parse(code)
        return any(isinstance(n, ast.FunctionDef) and n.name == "solve"
                   and not n.args.posonlyargs and not n.args.args and not n.args.kwonlyargs
                   and n.args.vararg is None and n.args.kwarg is None for n in parsed.body)
    except (SyntaxError, ValueError, TypeError, RecursionError):
        return False


def generation_metrics(predictions, references=None):
    result = {"rows": len(predictions),
              "syntax_and_solve_fraction": float(np.mean([syntax_ok(x) for x in predictions]))}
    if references is not None:
        if len(predictions) != len(references):
            raise ValueError("Prediction/reference length mismatch")
        result["exact_match_fraction"] = float(np.mean([p == r for p, r in zip(predictions, references)]))
    return result


def write_predictions(path, questions, predictions):
    if len(questions) != len(predictions) or any(not isinstance(p, str) for p in predictions):
        raise ValueError("Expected exactly one code string per question.")
    with open(path, "w", encoding="utf-8") as stream:
        for i, (q, p) in enumerate(zip(questions, predictions)):
            stream.write(json.dumps({"row_index": i, "question": q, "code": p}, ensure_ascii=False) + "\n")


def load_questions(path, question_key="question", expected_count=1919):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Upload the bot's ORIGINAL pass1_questions.jsonl; set QUESTIONS_PATH.")
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    if len(rows) != expected_count:
        raise ValueError(f"Expected {expected_count} tasks in bot order, got {len(rows)}.")
    if any(not isinstance(row, dict) or not isinstance(row.get(question_key), str)
           or not row[question_key].strip() for row in rows):
        raise ValueError(f"Expected nonempty string field {question_key!r}. Inspect the first row and set QUESTION_KEY.")
    return [row[question_key] for row in rows]


def export_submission(predictions, path, expected_count=1919):
    if len(predictions) != expected_count or any(not isinstance(p, str) for p in predictions):
        raise ValueError(f"Expected exactly {expected_count} program strings in the original bot order.")
    path = Path(path)
    if path.suffix != ".jsonl":
        raise ValueError("The bot accepts only a .jsonl file.")
    with open(path, "w", encoding="utf-8") as stream:
        for code in predictions:
            stream.write(json.dumps({"code": code}, ensure_ascii=False) + "\n")
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    assert len(rows) == expected_count and all(set(row) == {"code"} for row in rows)


def render_report(run_dir, output):
    run_dir = Path(run_dir)
    records = []
    if (run_dir / "metrics.jsonl").exists():
        records = [json.loads(line) for line in (run_dir / "metrics.jsonl").read_text().splitlines()]
    config = read_json(run_dir / "config.json") if (run_dir / "config.json").exists() else {}
    parts = ["<!doctype html><html lang='ru'><meta charset='utf-8'><title>HW2 — отчёт</title>",
             "<style>body{font:16px/1.6 system-ui;max-width:950px;margin:40px auto}pre{white-space:pre-wrap}"
             "[contenteditable]{background:#fff6d8;padding:12px}@media print{body{margin:0;font-size:11pt}}</style>",
             "<h1>HW2. Генерация кода</h1>",
             "<p><b>Черновик. Заполнить поля, добавить реальные результаты бота и T4, затем Печать → PDF.</b></p>"]
    sections = [
        ("Автор", "ФИО, группа, ссылка на код."),
        ("Постановка", "По вопросу генерируем Python solve(). Только разрешённый датасет, обучение с нуля. "
         "Опишите encoder/decoder, ограничения T4 и выбор размера модели."),
        ("Данные", "Укажите число шардов и строк, разбиение по хешу вопроса, обучение BPE только на train, "
         "доли длинных примеров. Целевые программы не изменялись и дополнительные таргеты не создавались."),
        ("Эксперименты", "Для КАЖДОГО запуска: гипотеза до запуска, одно изменение, размер выборки, seed, "
         "время, loss, синтаксис, pass@1 бота, вывод. Не записывайте незапущенные эксперименты как результаты."),
        ("Качество", "Вставьте подтверждённые public/private результаты. Loss, exact match и валидный синтаксис "
         "не равны pass@1. Укажите ограничения локальной валидации."),
        ("Скорость", "Укажите точную GPU, batch size, длину генерации, число вопросов, холодное полное время "
         "и время после прогрева из inference_metrics.json. Приложите выполненный ноутбук на одной T4."),
        ("Использование агента", "Агент прочитал задание и документацию инфраструктуры, написал исходный "
         "код и ноутбуки, предложил encoder-decoder baseline, кеширование и измерения. "
         "Дополните фактическими действиями, своими проверками, исправлениями и влиянием на решение."),
        ("Выводы", "Что подтвердилось, что не сработало, какой checkpoint выбран и почему."),
    ]
    for title, text in sections:
        parts += [f"<h2>{html.escape(title)}</h2><div contenteditable='true'>{html.escape(text)}</div>"]
    for filename, title in [("allocated_resources.json", "Выбранные ресурсы JupyterHub"),
                            ("environment.json", "Фактическая среда выполнения")]:
        if (run_dir / filename).is_file():
            parts += [f"<h2>{title}</h2><pre>" +
                      html.escape(json.dumps(read_json(run_dir / filename), ensure_ascii=False, indent=2)) + "</pre>"]
    parts += ["<h2>Фактическая конфигурация</h2><pre>" + html.escape(json.dumps(config, indent=2)) + "</pre>",
              "<h2>Фактическая валидация</h2><table><tr><th>Шаг</th><th>Loss</th><th>Token accuracy</th><th>Строк loss / всего</th></tr>"]
    for record in records:
        if record.get("kind") == "validation":
            values = [record.get(key) for key in ["step", "val_loss", "val_token_accuracy"]]
            values += [f"{record.get('val_loss_rows')} / {record.get('val_all_rows')}"]
            parts.append("<tr>" + "".join(f"<td>{html.escape(str(v))}</td>" for v in values) + "</tr>")
    recent = [r for r in records if r.get("kind") == "train"][-5:]
    parts += ["</table><h2>Последние замеры обучения</h2><pre>" +
              html.escape(json.dumps(recent, ensure_ascii=False, indent=2)) + "</pre>",
              "<p>Полные логи: metrics.jsonl; гипотезы и выводы: experiments.jsonl.</p>"]
    if (run_dir / "validation_generation.json").exists():
        parts += ["<h2>Локальная генерация (не pass@1)</h2><pre>" +
                  html.escape(json.dumps(read_json(run_dir / "validation_generation.json"), indent=2)) + "</pre>"]
    parts += ["<p>Источник задания: <a href='https://github.com/ashaba1in/hse-nlp/blob/2026/homeworks/hw2_code_generation.md'>HW2</a></p></html>"]
    Path(output).write_text("\n".join(parts), encoding="utf-8")
