"""Continue the user's last 107M weights and optimizer in a separate run."""
import argparse
import json
import math
from pathlib import Path

from omegaconf import OmegaConf
import torch

from src.trainer.trainer import Trainer
from src.utils.checkpoint import restore_random


def continuation_lr(local_step, steps, warmup, peak, floor=0.1):
    if local_step < warmup:
        return peak * (local_step + 1) / warmup
    progress = min(1.0, (local_step - warmup) / max(1, steps - warmup - 1))
    return peak * (floor + (1 - floor) * 0.5 * (1 + math.cos(math.pi * progress)))


class ContinuationTrainer(Trainer):
    def __init__(self, cfg, origin, additional_steps):
        self.origin = origin
        self.additional_steps = additional_steps
        self.parent_nll = None
        self.recovery_check = None
        super().__init__(cfg)

    def lr(self):
        return continuation_lr(self.step - self.origin, self.additional_steps, 200,
                               self.cfg.optimizer.lr, self.cfg.optimizer.min_lr_ratio)

    def validate(self):
        super().validate()
        records = [json.loads(line) for line in (self.run / 'metrics.jsonl').read_text().splitlines()]
        current = next(row for row in reversed(records) if 'val/nll' in row)
        if self.parent_nll is None:
            self.parent_nll = current['val/nll']
        if self.step - self.origin >= 2000 and self.recovery_check is None:
            improvement = self.parent_nll - current['val/nll']
            self.recovery_check = {'additional_steps': self.step - self.origin,
                                   'nll_improvement': improvement,
                                   'syntax_valid': current.get('val/syntax_valid')}
            if current.get('val/syntax_valid', 0) == 0 and improvement < 0.1:
                self.recovery_check['decision'] = 'stop_no_recovery'
                self.stop_requested = True
            else:
                self.recovery_check['decision'] = 'continue'
            (self.run / 'recovery_check.json').write_text(json.dumps(self.recovery_check, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--data-dir', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=30000)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--max-hours', type=float, default=2.5)
    args = parser.parse_args()
    if args.steps < 2000 or not 0 < args.lr <= 4e-5 or args.max_hours <= 0:
        raise ValueError('Invalid continuation budget')
    parent = args.checkpoint.resolve()
    run = args.run_dir.resolve()
    if parent.parent == run or parent.parent in run.parents:
        raise ValueError('Use a new run outside the parent directory')
    state = torch.load(parent, map_location='cpu', weights_only=False)
    if 'optimizer' not in state or 'rng' not in state:
        raise ValueError('Use the full last.pt checkpoint, not inference-only best.pt')
    if any(not torch.isfinite(value).all() for value in state['model'].values() if torch.is_tensor(value)):
        raise ValueError('Parent contains non-finite weights')
    if any(not torch.isfinite(value).all() for item in state['optimizer']['state'].values()
           for value in item.values() if torch.is_tensor(value)):
        raise ValueError('Parent contains non-finite optimizer state')
    cfg = OmegaConf.create(state['config'])
    cfg.data_dir = str(args.data_dir.resolve())
    cfg.run_dir = str(run)
    cfg.resume = None
    cfg.optimizer.lr = args.lr
    origin = state['step']
    cfg.trainer.max_steps = origin + args.steps
    cfg.trainer.max_hours = args.max_hours
    cfg.trainer.calibrate_budget = False
    cfg.trainer.warmup_steps = 200
    cfg.trainer.log_every = 100
    cfg.trainer.tensorboard = False
    trainer = ContinuationTrainer(cfg, origin, args.steps)
    for key in ['counts', 'tokenizer_sha256', 'vocab_size', 'model_vocab_size', 'max_source', 'max_target', 'seed', 'val_modulus']:
        if trainer.metadata[key] != state['metadata'][key]:
            raise ValueError('Original data or tokenizer differs: ' + key)
    if sum(p.numel() for p in trainer.model.parameters()) != 106977792:
        raise ValueError('Unexpected architecture')
    trainer.model.load_state_dict(state['model'])
    trainer.optimizer.load_state_dict(state['optimizer'])
    trainer.step, trainer.epoch, trainer.batch_cursor = origin, state['epoch'], state['batch_cursor']
    trainer.horizon = origin + args.steps
    trainer.elapsed = 0
    trainer.calibrated = True
    trainer.best = float('inf')
    restore_random(state['rng'])
    del state
    run.mkdir(parents=True, exist_ok=True)
    info = {'parent_checkpoint': str(parent), 'parent_global_step': origin,
            'additional_steps_max': args.steps, 'global_end_step': trainer.horizon,
            'learning_rate': args.lr, 'model_optimizer_rng_and_sampler_restored': True,
            'parent_modified': False, 'model_parameters': 106977792}
    (run / 'continuation.json').write_text(json.dumps(info, indent=2))
    trainer.validate()
    print('CONTINUATION_TRAINING_STARTED', json.dumps(info), flush=True)
    trainer.train()
    info.update(actual_global_step=trainer.step, actual_additional_steps=trainer.step - origin,
                best_nll=trainer.best, recovery_check=trainer.recovery_check)
    (run / 'continuation_completed.json').write_text(json.dumps(info, indent=2))


if __name__ == '__main__':
    main()
