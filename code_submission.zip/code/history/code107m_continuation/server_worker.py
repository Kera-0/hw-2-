"""Restore and continue only the user's 107M experiment."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
PARENT = Path.home() / 'codegen107_user/saved/h100_user_01'
DEPENDENCIES = Path.home() / 'codegen107_user/dependencies'
DATA = Path('/tmp/codegen107_resume')
RUN = ROOT / 'saved/continuation_01'
EXPORTS = ROOT / 'exports'
REVISION = 'b2724689ff079e9c22efd548fe134bfb29036dbb'


def state(phase, **values):
    record = {'phase': phase, 'updated_unix': time.time(), 'parameters': 106977792, **values}
    temporary = ROOT / 'worker_status.tmp.json'
    temporary.write_text(json.dumps(record, indent=2))
    temporary.replace(ROOT / 'worker_status.json')
    print(json.dumps(record), flush=True)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def relocate_completed_v2_cache():
    old_project = Path.home() / 'hse_hw2_130m_v2'
    if json.loads((old_project / 'worker_status.json').read_text())['phase'] != 'completed':
        raise RuntimeError('130M V2 must have completed before cache relocation')
    cache = old_project / 'run/train_token_shards'
    target = Path('/tmp/hw2_130m_v2_token_backup')
    target.mkdir(exist_ok=True)
    moved = []
    for i in range(30, 60):
        source = cache / f'{i:05d}.arrow'
        if source.is_symlink() or not source.is_file():
            continue
        destination = target / source.name
        if destination.exists() and sha(destination) != sha(source):
            raise ValueError('Existing relocated cache differs')
        if not destination.exists():
            shutil.copy2(source, destination)
        digest = sha(source)
        if sha(destination) != digest:
            raise ValueError('Relocated cache checksum differs')
        link = source.with_suffix('.relocated-link')
        link.symlink_to(destination)
        size = source.stat().st_size
        os.replace(link, source)
        moved.append({'source': str(source), 'target': str(destination), 'sha256': digest, 'bytes': size})
    (ROOT / 'cache_relocation.json').write_text(json.dumps({'only_new_v2_training_cache': moved,
            'old_130m_and_107m_weights_unchanged': True}, indent=2))


def main():
    os.chdir(ROOT)
    DATA.mkdir(exist_ok=True)
    EXPORTS.mkdir(exist_ok=True)
    if not (PARENT / 'last.pt').is_file():
        raise FileNotFoundError('Original 107M full last.pt checkpoint is missing')
    if shutil.disk_usage(ROOT).free < 4_500_000_000:
        state('relocating_rebuildable_v2_cache')
        relocate_completed_v2_cache()
    if shutil.disk_usage(ROOT).free < 4_000_000_000:
        raise RuntimeError('Insufficient disk for resumable checkpoints; no old weights removed')
    os.environ.update(PYTHONPATH=str(DEPENDENCIES) + os.pathsep + str(ROOT),
                      HF_ENDPOINT='https://huggingface.artifactory.s.o3.ru/artifactory/api/huggingfaceml/huggingface-remote',
                      HF_HUB_DISABLE_XET='1', HF_HUB_DISABLE_IMPLICIT_TOKEN='1',
                      HF_HOME=str(DATA / 'hf_cache'), HF_HUB_DOWNLOAD_TIMEOUT='120',
                      OMP_NUM_THREADS='8', RAYON_NUM_THREADS='24', TOKENIZERS_PARALLELISM='true')
    sys.path.insert(0, str(DEPENDENCIES))
    from huggingface_hub import hf_hub_download
    raw = DATA / 'raw'
    raw.mkdir(exist_ok=True)
    state('restoring_original_public_data')
    def fetch(i):
        name = f'part-{i:05d}.parquet'
        destination = raw / name
        if not destination.exists():
            candidates = [Path('/tmp/hw2_130m_v2_raw/data/train') / name,
                          Path('/tmp/codegen107_user/raw_train') / name]
            source = next((p for p in candidates if p.is_file()), None)
            if source is not None:
                destination.symlink_to(source.resolve())
            else:
                path = hf_hub_download('SlavaYus/tinysms_qa_12m', 'data/train/' + name,
                                       repo_type='dataset', revision=REVISION, token=False,
                                       local_dir=str(DATA / 'downloads'), etag_timeout=90)
                destination.symlink_to(Path(path).resolve())
        print(json.dumps({'public_shard_ready': i + 1}), flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(fetch, range(60)))
    processed = DATA / 'processed'
    if not (processed / 'metadata.json').is_file():
        state('rebuilding_own_107m_tokens')
        subprocess.run([sys.executable, '-u', 'prepare_existing.py', '--parent-run', str(PARENT),
                        '--raw', str(raw), '--output', str(processed)], cwd=ROOT,
                       env=os.environ.copy(), timeout=2 * 3600, check=True)
    checkpoint = RUN / 'last.pt' if (RUN / 'last.pt').is_file() else PARENT / 'last.pt'
    if checkpoint.parent == RUN:
        raise RuntimeError('A continuation checkpoint already exists; inspect it before extending the budget')
    state('training', parent_step=90000, additional_steps_max=30000, global_end_step=120000,
          learning_rate=1e-5, recovery_check_after=2000)
    subprocess.run([sys.executable, '-u', 'continue_train.py', '--checkpoint', str(checkpoint),
                    '--data-dir', str(processed), '--run-dir', str(RUN), '--steps', '30000',
                    '--lr', '0.00001', '--max-hours', '2.5'], cwd=ROOT,
                   env=os.environ.copy(), timeout=3 * 3600, check=True)
    summary = json.loads((RUN / 'continuation_completed.json').read_text())
    recovery = summary.get('recovery_check') or {}
    phase = 'stopped_early_no_recovery' if recovery.get('decision') == 'stop_no_recovery' else 'completed'
    questions = Path.home() / 'hse_hw2_130m_v2/delivery/questions_used.jsonl'
    if not questions.is_file():
        raise FileNotFoundError('Official test questions missing')
    shutil.copyfile(questions, EXPORTS / 'questions_used.jsonl')
    state('exporting_answers', **summary)
    subprocess.run([sys.executable, '-u', 'inference.py', '--checkpoint', str(RUN / 'best.pt'),
                    '--tokenizer', str(RUN / 'tokenizer.json'), '--questions', str(EXPORTS / 'questions_used.jsonl'),
                    '--output', str(EXPORTS / 'submission_107m.jsonl'), '--batch-size', '128',
                    '--max-new-tokens', '256'], cwd=ROOT, env=os.environ.copy(), timeout=900, check=True)
    with zipfile.ZipFile(EXPORTS / 'checkpoint_107m.zip', 'w', zipfile.ZIP_STORED) as archive:
        for name in ['best.pt', 'tokenizer.json', 'config.yaml', 'data_metadata.json']:
            archive.write(RUN / name, 'model/' + name)
    for name in ['metrics.jsonl', 'config.yaml', 'environment.json', 'data_metadata.json',
                 'continuation.json', 'continuation_completed.json', 'recovery_check.json']:
        source = RUN / name
        if source.is_file():
            shutil.copyfile(source, EXPORTS / name)
    state(phase, **summary)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        state('failed', error_type=type(error).__name__)
        raise
