"""Rebuild the original 107M dataset using its exact saved tokenizer."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from types import SimpleNamespace

from tokenizers import Tokenizer
import prepare as original


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent-run', type=Path, required=True)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    metadata = json.loads((args.parent_run / 'data_metadata.json').read_text())
    tokenizer_path = args.parent_run / 'tokenizer.json'
    if hashlib.sha256(tokenizer_path.read_bytes()).hexdigest() != metadata['tokenizer_sha256']:
        raise ValueError('Original 107M tokenizer checksum differs')
    if len(list(args.raw.glob('*.parquet'))) != 60:
        raise ValueError('All 60 pinned official training shards are required')
    def reuse_tokenizer(texts, path, vocab_size):
        shutil.copyfile(tokenizer_path, path)
        return Tokenizer.from_file(str(path))
    original.train_tokenizer = reuse_tokenizer
    original.prepare(SimpleNamespace(
        output=str(args.output), local_parquet=str(args.raw), seed=metadata['seed'],
        vocab_size=metadata['model_vocab_size'], max_source=metadata['max_source'],
        max_target=metadata['max_target'], val_modulus=metadata['val_modulus'],
        tokenizer_rows_per_shard=metadata['tokenizer_rows_per_shard']))
    rebuilt = json.loads((args.output / 'metadata.json').read_text())
    for key in ['counts', 'tokenizer_sha256', 'vocab_size', 'model_vocab_size', 'max_source',
                'max_target', 'seed', 'val_modulus', 'length_quantiles']:
        if rebuilt[key] != metadata[key]:
            raise ValueError('Rebuilt original data differs: ' + key)
    print('ORIGINAL_107M_DATA_RECONSTRUCTED_EXACT_COUNTS_AND_TOKENIZER', flush=True)


if __name__ == '__main__':
    main()
