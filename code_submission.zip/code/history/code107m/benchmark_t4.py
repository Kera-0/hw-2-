"""Cold subprocess wall time, including imports and the complete 1919-row inference."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', default='model/best.pt')
    parser.add_argument('--tokenizer', default='model/tokenizer.json')
    parser.add_argument('--questions', default='questions_used.jsonl')
    parser.add_argument('--output', default='outputs/submission_107m.jsonl')
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--max-new-tokens', type=int, default=256)
    parser.add_argument('--allow-other-gpu', action='store_true')
    args = parser.parse_args()
    command = [sys.executable, str(Path(__file__).with_name('inference.py')),
               '--checkpoint', args.checkpoint, '--tokenizer', args.tokenizer,
               '--questions', args.questions, '--output', args.output,
               '--batch-size', str(args.batch_size), '--max-new-tokens', str(args.max_new_tokens),
               '--expected-count', '1919', '--device', 'cuda', '--dtype', 'fp16']
    if not args.allow_other_gpu:
        command.append('--require-t4')
    started = time.perf_counter()
    subprocess.run(command, check=True, timeout=900)
    seconds = time.perf_counter() - started
    timing_path = Path(args.output).with_suffix('.timing.json')
    report = json.loads(timing_path.read_text())
    report.update(cold_subprocess_seconds=seconds,
                  under_180_seconds=seconds <= 180,
                  t4_limit_verified=report['actual_t4'] and seconds <= 180)
    timing_path.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    if not args.allow_other_gpu and not report['t4_limit_verified']:
        raise RuntimeError('This run did not satisfy the T4 180-second limit')


if __name__ == '__main__':
    main()
