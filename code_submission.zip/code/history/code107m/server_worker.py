"""Isolated H100 job for the supplied Code107M project; no other model imports."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
DATASET = 'SlavaYus/tinysms_qa_12m'
REVISION = 'b2724689ff079e9c22efd548fe134bfb29036dbb'
NATIVE_PYTHON = sys.executable
DEPENDENCIES = ROOT / 'dependencies'
DATA = Path('/tmp/codegen107_user')
RUN = ROOT / 'saved/h100_user_01'
EXPORTS = ROOT / 'exports'


def state(phase, **extra):
    record = {'phase': phase, 'updated_unix': time.time(), 'parameters': 106977792, **extra}
    (ROOT / 'worker_status.json').write_text(json.dumps(record, indent=2))
    print(json.dumps(record), flush=True)


def command(args, timeout=36000, **kwargs):
    return subprocess.run([NATIVE_PYTHON, '-u', *args], cwd=ROOT, env=os.environ.copy(),
                          timeout=timeout, check=True, **kwargs)


def main():
    os.chdir(ROOT)
    DATA.mkdir(exist_ok=True)
    EXPORTS.mkdir(exist_ok=True)
    os.environ.update(HF_HUB_DISABLE_XET='1', HF_HUB_DISABLE_IMPLICIT_TOKEN='1',
                      HF_ENDPOINT='https://huggingface.artifactory.s.o3.ru/artifactory/api/huggingfaceml/huggingface-remote',
                      HF_HOME=str(DATA / 'hf_cache'), HF_HUB_ETAG_TIMEOUT='90', HF_HUB_DOWNLOAD_TIMEOUT='120',
                      OMP_NUM_THREADS='8', RAYON_NUM_THREADS='24', TOKENIZERS_PARALLELISM='false')
    if not (DEPENDENCIES / '.installed').is_file():
        state('installing_dependencies')


        packages = [line.strip() for line in (ROOT / 'requirements.txt').read_text().splitlines()
                    if line.strip() and not line.startswith('#') and not line.startswith('torch==')]
        command(['-m', 'pip', 'install', '--no-cache-dir', '--target', str(DEPENDENCIES),
                 '--index-url', 'https://artifactory.s.o3.ru/artifactory/api/pypi/pypi-virtual/simple', *packages], timeout=1800)
        (DEPENDENCIES / '.installed').write_text(json.dumps(packages))
    os.environ['PYTHONPATH'] = str(DEPENDENCIES) + os.pathsep + str(ROOT)
    sys.path.insert(0, str(DEPENDENCIES))
    from huggingface_hub import hf_hub_download
    state('testing')
    test = command(['-m', 'pytest', '-q'], timeout=300, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (EXPORTS / 'pytest_result.txt').write_text(test.stdout)
    print(test.stdout, flush=True)
    state('downloading_original_train')
    raw = DATA / 'raw_train'
    raw.mkdir(exist_ok=True)
    def download(i):
        name = f'part-{i:05d}.parquet'
        target = raw / name


        cached = Path('/tmp/hse_hw2_data/data/train') / name
        if not target.exists() and cached.exists():
            shutil.copyfile(cached, target)
        if not target.exists():
            found = hf_hub_download(DATASET, 'data/train/' + name, repo_type='dataset',
                                    revision=REVISION, local_dir=str(DATA / 'downloads'), token=False, etag_timeout=90)
            shutil.copyfile(found, target)
        print(json.dumps({'downloaded_train_shard': i + 1}), flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(download, range(60)))
    manifest = {'dataset': DATASET, 'revision': REVISION,
                'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.glob('*.parquet'))}}
    (EXPORTS / 'raw_data_manifest.json').write_text(json.dumps(manifest, indent=2))
    prepared = DATA / 'processed'
    if not (prepared / 'metadata.json').exists():
        state('preparing_own_tokenizer_and_data')
        env = os.environ.copy()
        env['TOKENIZERS_PARALLELISM'] = 'true'
        subprocess.run([NATIVE_PYTHON, '-u', 'prepare.py', '--local-parquet', str(raw), '--output', str(prepared)],
                       cwd=ROOT, env=env, check=True, timeout=4 * 3600)
    state('gpu_preflight')
    command(['preflight.py', '-cn', 'h100_user_run'], timeout=600)
    started = time.perf_counter()
    state('training', max_steps=90000, max_training_hours=8)
    args = ['train.py', '-cn', 'h100_user_run']
    if (RUN / 'last.pt').exists():
        args.append('resume=' + str(RUN / 'last.pt'))
    command(args, timeout=9 * 3600)
    training_hours = (time.perf_counter() - started) / 3600
    metrics = [json.loads(line) for line in (RUN / 'metrics.jsonl').read_text().splitlines()]
    summary = {'completed': True, 'parameters': 106977792,
               'steps': max(row['step'] for row in metrics), 'training_hours': training_hours,
               'max_hours_configured': 8, 'max_steps_configured': 90000,
               'planned_steps': next((r['planned_steps'] for r in metrics if 'planned_steps' in r), 90000),
               'dataset': DATASET, 'revision': REVISION, 'official_pass_at_1': None, 't4_measured': False}
    (EXPORTS / 'training_summary.json').write_text(json.dumps(summary, indent=2))
    state('exporting_answers')
    import pyarrow.parquet as pq
    test_path = hf_hub_download(DATASET, 'data/test/test.parquet', repo_type='dataset', revision=REVISION,
                                local_dir=str(DATA / 'test'), token=False, etag_timeout=90)
    questions = pq.read_table(test_path, columns=['question'])['question'].to_pylist()
    if len(questions) != 1919:
        raise ValueError('Official test row count changed')
    question_path = EXPORTS / 'questions_used.jsonl'
    question_path.write_text(''.join(json.dumps({'question': q}, ensure_ascii=False) + '\n' for q in questions))
    (EXPORTS / 'question_source.json').write_text(json.dumps({'dataset': DATASET, 'revision': REVISION,
               'file': 'data/test/test.parquet', 'original_bot_order_verified': False}, indent=2))
    command(['inference.py', '--checkpoint', str(RUN / 'best.pt'), '--tokenizer', str(RUN / 'tokenizer.json'),
             '--questions', str(question_path), '--output', str(EXPORTS / 'submission_107m.jsonl'),
             '--batch-size', '128', '--max-new-tokens', '256'], timeout=900)
    with zipfile.ZipFile(EXPORTS / 'checkpoint_107m.zip', 'w', zipfile.ZIP_STORED) as archive:
        for name in ['best.pt', 'tokenizer.json', 'config.yaml', 'data_metadata.json']:
            archive.write(RUN / name, 'model/' + name)
    for name in ['config.yaml', 'environment.json', 'data_metadata.json', 'metrics.jsonl', 'source_manifest.json']:
        shutil.copyfile(RUN / name, EXPORTS / name)
    shutil.copyfile(ROOT / 'outputs/preflight.json', EXPORTS / 'preflight.json')
    state('completed', **summary)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        state('failed', error_type=type(error).__name__)
        raise
