#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS=8
export HF_HUB_DISABLE_IMPLICIT_TOKEN=1
# Preparation trains BPE on CPU. First run prepare.py separately before this script.
python preflight.py hardware=h100 "$@"
python train.py hardware=h100 "$@"
