#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export TOKENIZERS_PARALLELISM=true
export RAYON_NUM_THREADS=24
export HF_HUB_DISABLE_IMPLICIT_TOKEN=1
python prepare.py "$@"
