"""Restore train-only tokenizer and the original validation split without loading model weights."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import zipfile

import hw2_core as h


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, default=Path('delivery/checkpoint_130m.zip'))
    parser.add_argument('--source-dir', type=Path, default=Path('work/data'))
    parser.add_argument('--baseline', type=Path, default=Path('work/baseline_assets'))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    recorded = h.read_json(root / 'artifacts/130m_data_manifest.json')
    signature = recorded['signature']
    cfg = h.Config(**h.read_json(root / 'artifacts/130m_config.json'))
    args.baseline.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.checkpoint) as archive:
        tokenizer_bytes = archive.read('best/tokenizer.json')
    tokenizer_hash = hashlib.sha256(tokenizer_bytes).hexdigest()
    if tokenizer_hash != signature['tokenizer_sha256']:
        raise ValueError('Unexpected tokenizer; use the supplied 130M checkpoint')
    marker = args.baseline / 'prepared.json'
    expected = {'revision': h.REVISION, 'tokenizer_sha256': tokenizer_hash,
                'seed': cfg.seed, 'val_size': cfg.val_size, 'baseline_raw_rows': 1_000_000}
    if marker.exists():
        if h.read_json(marker) != expected:
            raise ValueError('Preparation settings changed; choose a new baseline directory')
        if h.file_hash(args.baseline / 'tokenizer.json') != tokenizer_hash:
            raise ValueError('Prepared tokenizer changed')
        if h.read_json(args.baseline / 'config.json') != asdict(cfg):
            raise ValueError('Prepared config changed')
        if not (args.baseline / 'val_arrow/dataset_info.json').is_file():
            raise ValueError('Validation cache is missing')
        print('PREPARATION_ALREADY_COMPLETED')
        return
    h.download_files(args.source_dir, shard_count=6)
    raw_cfg = h.Config(seed=cfg.seed, shard_count=6, max_rows=1_000_000, val_size=cfg.val_size)
    raw = h.load_raw(args.source_dir, raw_cfg)
    val = raw.filter(lambda batch: [h.question_bucket(q) >= 980 for q in batch['question']],
                     batched=True, desc='Original question-group validation split')
    val = val.select(range(min(cfg.val_size, len(val))))
    if len(val) != 1024:
        raise ValueError('Expected the original 1024 validation rows')
    tokenizer_path = args.baseline / 'tokenizer.json'
    tokenizer_path.write_bytes(tokenizer_bytes)
    val = val.map(h.tokenize_batch, batched=True, batch_size=2048,
                  fn_kwargs={'tokenizer_path': str(tokenizer_path.resolve())}, desc='Tokenize validation')
    val.save_to_disk(str(args.baseline / 'val_arrow'))
    h.write_json(args.baseline / 'config.json', asdict(cfg))
    h.write_json(marker, expected)
    print(json.dumps({'validation_rows': len(val), 'tokenizer_sha256': tokenizer_hash,
                      'model_weights_loaded': False}))


if __name__ == '__main__':
    main()
