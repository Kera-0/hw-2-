"""Train a 130,183,936-parameter encoder-decoder from random initialization.

Only original allowed training rows/targets are used. The baseline train-only
tokenizer and question-hash validation split are retained for fair comparison.
Arrow streaming avoids duplicating the expanded corpus on the small GPU disk.
"""
from dataclasses import asdict, replace
from pathlib import Path
import argparse
import gc
import json
import math
import os
import random
import shutil
import time
import zipfile

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from datasets import Dataset, concatenate_datasets, load_from_disk
from huggingface_hub import hf_hub_download
from tokenizers import Tokenizer
from transformers import get_cosine_schedule_with_warmup

import hw2_core as h
from safe_numeric import compare

PARAMETERS = 130_183_936


def prepare_training(run, tokenizer, shards, cfg, source):
    """Write int32 token IDs directly, without caching raw or intermediate Arrow."""
    token_dir = run / 'train_token_shards'
    token_dir.mkdir(exist_ok=True)
    manifest_path = run / 'data_manifest.json'
    signature = {'dataset': h.DATASET, 'revision': h.REVISION, 'shards': shards,
                 'tokenizer_sha256': h.file_hash(run / 'tokenizer.json'),
                 'max_source': cfg.max_source, 'max_target': cfg.max_target,
                 'split': 'normalized_question_sha256_mod_1000_lt_980'}
    if manifest_path.exists():
        if h.read_json(manifest_path)['signature'] != signature:
            raise ValueError('Training data signature changed')
        return concatenate_datasets([Dataset.from_file(str(token_dir / f'{i:05d}.arrow')) for i in range(shards)])
    schema = pa.schema([('source_ids', pa.list_(pa.int32())), ('target_ids', pa.list_(pa.int32())),
                        ('n_source', pa.int16()), ('n_target', pa.int16())])
    stats = {'signature': signature, 'raw_rows': 0, 'heldout_rows_excluded': 0,
             'overlength_rows_excluded': 0, 'train_rows': 0, 'targets_modified': False}
    for i in range(shards):
        destination = token_dir / f'{i:05d}.arrow'
        part_manifest = token_dir / f'{i:05d}.json'
        if destination.exists() and part_manifest.exists():
            part = h.read_json(part_manifest)
            if part['signature'] != signature:
                raise ValueError('Per-shard data signature changed')
            for key in ['raw_rows', 'heldout_rows_excluded', 'overlength_rows_excluded', 'train_rows']:
                stats[key] += part[key]
            print(json.dumps({'kind': 'data_progress', 'shard': i + 1, 'shards': shards, 'rows': stats['train_rows'], 'cached': True}), flush=True)
            continue
        previous = {key: stats[key] for key in ['raw_rows', 'heldout_rows_excluded', 'overlength_rows_excluded', 'train_rows']}
        temporary = destination.with_suffix('.tmp.arrow')
        with pa.OSFile(str(temporary), 'wb') as stream:
            with pa.ipc.new_stream(stream, schema) as writer:
                name = f'data/train/part-{i:05d}.parquet'
                path = source / name
                if not path.is_file():
                    print(json.dumps({'kind': 'download_start', 'shard': i + 1, 'file': name}), flush=True)
                    path = Path(hf_hub_download(h.DATASET, name, repo_type='dataset', revision=h.REVISION,
                                               local_dir=str(source), etag_timeout=20))
                for batch in pq.ParquetFile(path).iter_batches(batch_size=8192, columns=['question', 'code']):
                    batch = batch.to_pydict()
                    stats['raw_rows'] += len(batch['question'])
                    keep = [j for j, q in enumerate(batch['question']) if h.question_bucket(q) < 980]
                    stats['heldout_rows_excluded'] += len(batch['question']) - len(keep)
                    sources = tokenizer.encode_batch([batch['question'][j] for j in keep], add_special_tokens=False)
                    targets = tokenizer.encode_batch([batch['code'][j] for j in keep], add_special_tokens=False)
                    src, tgt = [], []
                    for s, t in zip(sources, targets):
                        if len(s.ids) + 1 <= cfg.max_source and len(t.ids) + 1 <= cfg.max_target:
                            src.append(s.ids + [h.EOS])
                            tgt.append(t.ids + [h.EOS])
                        else:
                            stats['overlength_rows_excluded'] += 1
                    if src:
                        writer.write_batch(pa.RecordBatch.from_pydict(
                            {'source_ids': src, 'target_ids': tgt,
                             'n_source': list(map(len, src)), 'n_target': list(map(len, tgt))}, schema=schema))
                        stats['train_rows'] += len(src)
                free = shutil.disk_usage(run).free
                print(json.dumps({'kind': 'data_progress', 'shard': i + 1, 'shards': shards,
                                  'rows': stats['train_rows'], 'free_disk_gb': round(free / 1e9, 2)}), flush=True)
                if free < 4_000_000_000:
                    raise RuntimeError('Insufficient free disk for resumable model checkpoints')
        os.replace(temporary, destination)
        h.write_json(part_manifest, {'signature': signature, **{key: stats[key] - previous[key] for key in previous}})
    stats['arrow_bytes'] = sum((token_dir / f'{i:05d}.arrow').stat().st_size for i in range(shards))
    h.write_json(manifest_path, stats)
    return concatenate_datasets([Dataset.from_file(str(token_dir / f'{i:05d}.arrow')) for i in range(shards)])


def export_submission(checkpoint, val, exports, question_path):
    model, tokenizer, cfg, device = h.load_inference(checkpoint)
    references, questions_val = list(val['code']), list(val['question'])
    experiments = []
    for limit in [128, 192, 256]:
        begin = time.perf_counter()
        predictions, diagnostics = h.predict(model, tokenizer, questions_val, cfg, device,
                                             batch_size=128, max_new_tokens=limit)
        result = {'limit': limit, 'seconds_h100': time.perf_counter() - begin,
                  **compare(predictions, references), **diagnostics}
        experiments.append(result)
        print(json.dumps({'kind': 'final_decoding_experiment', **result}), flush=True)
    best_accuracy = max(x['functional_accuracy'] for x in experiments)

    selected = min((x for x in experiments if x['functional_accuracy'] >= best_accuracy - 0.0025),
                   key=lambda x: x['limit'])
    limit = selected['limit']
    h.write_json(exports / 'decoding_experiments_130m.json', experiments)
    questions = [json.loads(line)['question'] for line in question_path.read_text().splitlines()]
    h.synchronize(device)
    begin = time.perf_counter()
    predictions, diagnostics = h.predict(model, tokenizer, questions, cfg, device,
                                         batch_size=128, max_new_tokens=limit)
    h.synchronize(device)
    seconds = time.perf_counter() - begin
    h.export_submission(predictions, exports / 'submission_130m.jsonl')
    meta = h.read_json(checkpoint / 'training_meta.json')
    info = {'parameters': PARAMETERS, 'checkpoint_step': meta['step'], 'max_new_tokens': limit,
            'validation_functional_accuracy': selected['functional_accuracy'],
            'reference_eligible': selected['reference_eligible'], 'official_pass_at_1': None,
            'generation_seconds_h100': seconds, 'gpu': torch.cuda.get_device_name(),
            't4_measured': False, 'required_t4_max_seconds': 180,
            'question_source': 'official_hf_test_in_parquet_order', 'original_bot_order_verified': False,
            'questions_sha256': h.file_hash(question_path),
            'submission_sha256': h.file_hash(exports / 'submission_130m.jsonl'), **diagnostics}
    h.write_json(exports / 'submission_130m_info.json', info)
    h.write_json(checkpoint / 'inference_config.json', {'max_new_tokens': limit, 'batch_size': 128,
                 'expected_rows': 1919, 'max_source': cfg.max_source, 'max_target': cfg.max_target})
    with zipfile.ZipFile(exports / 'checkpoint_130m.zip', 'w', compression=zipfile.ZIP_STORED) as archive:
        for name in ['config.json', 'generation_config.json', 'model.safetensors', 'tokenizer.json', 'training_meta.json', 'inference_config.json']:
            archive.write(checkpoint / name, 'best/' + name)
    h.write_json(exports / 'completed_130m.json', info)
    print('TRAINING_AND_SUBMISSION_COMPLETED', json.dumps(info), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--steps', type=int, default=40000)
    parser.add_argument('--shards', type=int, default=30)
    parser.add_argument('--run-name', default='h100_130m_01')
    parser.add_argument('--baseline', type=Path, default=Path('work/baseline_assets'))
    parser.add_argument('--runs-dir', type=Path, default=Path('work/runs'))
    parser.add_argument('--source-dir', type=Path, default=Path('work/data'))
    parser.add_argument('--exports', type=Path, default=Path('work/exports'))
    parser.add_argument('--questions', type=Path, default=Path('delivery/questions_used.jsonl'))
    args = parser.parse_args()
    if not 1 <= args.shards <= 60 or not 1 <= args.steps:
        raise ValueError('Invalid experiment size')
    torch.set_num_threads(8)
    baseline = args.baseline.resolve()
    run = args.runs_dir.resolve() / args.run_name
    exports = args.exports.resolve()
    run.mkdir(parents=True, exist_ok=True)
    exports.mkdir(parents=True, exist_ok=True)
    cfg = replace(h.Config(**h.read_json(baseline / 'config.json')),
                  d_model=1024, encoder_layers=6, decoder_layers=3, heads=16, ffn=3840,
                  batch_size=128, accumulation=2, steps=args.steps, warmup=min(1000, args.steps // 10),
                  eval_every=1000, save_every=1000, log_every=100, lr=3e-4,
                  shard_count=args.shards, max_rows=6_000_000, tokenization_processes=8)
    assert h.count_parameters(cfg, 8192) == PARAMETERS
    if (run / 'config.json').exists() and h.read_json(run / 'config.json') != asdict(cfg):
        raise ValueError('Use a new run name when changing model/training settings')
    h.write_json(run / 'config.json', asdict(cfg))
    (run / 'tokenizer.json').write_bytes((baseline / 'tokenizer.json').read_bytes())
    tok = Tokenizer.from_file(str(run / 'tokenizer.json'))
    h.append_event(run / 'experiments.jsonl', {
        'kind': 'hypothesis', 'hypothesis': 'A randomly initialized 130M encoder-decoder trained longer on more original data improves numeric agreement.',
        'parameters': PARAMETERS, 'steps': cfg.steps, 'shards': args.shards,
        'changes_relative_to_baseline': ['model_width', 'training_data_size', 'optimization_budget'],
        'ablation_limitation': 'This requested scaling run changes multiple factors; gains cannot be attributed to model size alone.',
        'validation': 'Same heldout questions; excluded hash buckets on every new shard.',
        'extra_training_targets': False, 'pretrained_weights': False})
    train_ds = prepare_training(run, tok, args.shards, cfg, args.source_dir.resolve())
    val = load_from_disk(str(baseline / 'val_arrow'))
    h.seed_all(cfg.seed)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required')
    device = torch.device('cuda:0')
    model = h.make_model(cfg, tok.get_vocab_size()).to(device)
    assert sum(p.numel() for p in model.parameters()) == PARAMETERS
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay, fused=True)
    scheduler = get_cosine_schedule_with_warmup(optimizer, cfg.warmup, cfg.steps)
    start, epoch, position = 0, 0, 0
    best_accuracy, best_loss = -1.0, float('inf')
    if (run / 'last.pt').exists():
        state = torch.load(run / 'last.pt', map_location='cpu', weights_only=True)
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        scheduler.load_state_dict(state['scheduler'])
        start, epoch, position = state['step'], state['epoch'], state['next_batch']
        best_accuracy, best_loss = state['best_accuracy'], state['best_loss']
        torch.set_rng_state(state['torch_rng'])
        torch.cuda.set_rng_state_all(state['cuda_rng'])
        random.setstate(state['python_rng'])
        del state
    h.write_json(run / 'environment.json', {'parameters': PARAMETERS, 'gpu': torch.cuda.get_device_name(),
                  'torch': str(torch.__version__), 'precision': str(h.precision(device)),
                  'train_rows': len(train_ds), 'val_rows': len(val), 'free_disk_bytes': shutil.disk_usage(run).free})
    batches = h.BatchStream(train_ds, cfg, device, epoch, position)
    questions, references = list(val['question']), list(val['code'])
    print('TRAINING_STARTED', json.dumps({'parameters': PARAMETERS, 'steps': cfg.steps,
          'start_step': start, 'train_rows': len(train_ds), 'effective_batch': cfg.batch_size * cfg.accumulation}), flush=True)
    model.train()
    output = batch = state = None
    for step in range(start + 1, cfg.steps + 1):
        begin = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss_value = 0.0
        for _ in range(cfg.accumulation):
            batch = next(batches)
            with h.autocast(device):
                output = model(**batch, use_cache=False)
                loss = output.loss / cfg.accumulation
            if not torch.isfinite(loss):
                raise FloatingPointError('Non-finite loss; last checkpoint retained')
            loss.backward()
            loss_value += float(loss.detach())
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()
        h.synchronize(device)
        elapsed = time.perf_counter() - begin
        if step == 1 or step % cfg.log_every == 0:
            event = {'kind': 'train', 'step': step, 'train_loss': loss_value,
                     'lr': scheduler.get_last_lr()[0], 'step_seconds': elapsed,
                     'minutes_train_left_estimate': (cfg.steps - step) * elapsed / 60,
                     'gpu_peak_memory_gb': torch.cuda.max_memory_allocated() / 1e9}
            h.append_event(run / 'metrics.jsonl', event)
            print(json.dumps(event), flush=True)
        if step % cfg.eval_every == 0 or step == cfg.steps:
            scores = h.evaluate_loss(model, val, cfg, device)
            predictions, diagnostics = h.predict(model, tok, questions, cfg, device,
                                                 batch_size=128, max_new_tokens=192)
            scores.update(compare(predictions, references))
            event = {'kind': 'validation', 'step': step, **scores, **diagnostics}
            h.append_event(run / 'metrics.jsonl', event)
            print(json.dumps(event), flush=True)
            accuracy = scores['functional_accuracy']
            if accuracy > best_accuracy or (accuracy == best_accuracy and scores['val_loss'] < best_loss):
                best_accuracy, best_loss = accuracy, scores['val_loss']
                h.save_inference(model, tok, run / 'best', cfg, step)
                meta = h.read_json(run / 'best/training_meta.json')
                meta.update(best_validation=event, tokenizer_source='original_baseline_train_only')
                h.write_json(run / 'best/training_meta.json', meta)
                h.write_predictions(run / 'validation_best.jsonl', questions, predictions)
            model.train()
        if step % cfg.save_every == 0 or step == cfg.steps:
            state = {'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(),
                     'step': step, 'best_accuracy': best_accuracy, 'best_loss': best_loss,
                     'epoch': batches.epoch, 'next_batch': batches.next_batch,
                     'torch_rng': torch.get_rng_state(), 'python_rng': random.getstate(),
                     'cuda_rng': torch.cuda.get_rng_state_all()}
            torch.save(state, run / 'last.tmp.pt')
            os.replace(run / 'last.tmp.pt', run / 'last.pt')
    h.write_json(run / 'completed.json', {'steps': cfg.steps, 'best_accuracy': best_accuracy})
    del model, optimizer, scheduler, output, batch, state
    gc.collect()
    torch.cuda.empty_cache()
    export_submission(run / 'best', val, exports, args.questions.resolve())


if __name__ == '__main__':
    main()
