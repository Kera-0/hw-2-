"""Bounded AST interpreter for arithmetic validation; never exec/eval model code.

Unsupported Python is reported as such. This is a local comparison, not the bot's
sandbox or an official pass@1 measurement. Test answers are never training data.
"""
import ast
import math
import operator
from fractions import Fraction


class Unsupported(ValueError):
    pass


class Returned(Exception):
    def __init__(self, value):
        self.value = value


BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
       ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
       ast.Mod: operator.mod, ast.Pow: operator.pow}
CMP = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
       ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
       ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b}
FUNCS = {'int': int, 'float': float, 'abs': abs, 'round': round,
         'min': min, 'max': max, 'sum': sum, 'len': len, 'pow': pow,
         'range': range, 'sorted': sorted, 'divmod': divmod,
         'Fraction': Fraction, 'bool': bool}
MATH = {k: getattr(math, k) for k in (
    'ceil', 'floor', 'sqrt', 'log', 'log2', 'log10', 'exp', 'fabs', 'trunc',
    'sin', 'cos', 'tan', 'radians', 'degrees', 'gcd', 'lcm', 'pi', 'e')}


class Interpreter:
    def __init__(self):
        self.remaining = 30000
        self.env = dict(FUNCS)
        self.env['math'] = MATH
        self.depth = 0

    def tick(self):
        self.remaining -= 1
        if self.remaining < 0:
            raise Unsupported('operation budget')

    def bounded(self, v):
        if isinstance(v, (list, tuple, str, range, dict)) and len(v) > 10000:
            raise Unsupported('container size')
        if isinstance(v, int) and v.bit_length() > 4096:
            raise Unsupported('integer size')
        return v

    def assign(self, target, value):
        if isinstance(target, ast.Name):
            if target.id.startswith('__'):
                raise Unsupported('private name')
            self.env[target.id] = self.bounded(value)
        elif isinstance(target, (ast.Tuple, ast.List)) and len(target.elts) == len(value):
            for t, v in zip(target.elts, value):
                self.assign(t, v)
        else:
            raise Unsupported('assignment')

    def binary(self, op, a, b):
        if isinstance(op, ast.Pow) and (abs(b) > 4096 or abs(a) > 1e100):
            raise Unsupported('power size')
        if isinstance(op, ast.Mult):
            for seq, number in ((a, b), (b, a)):
                if isinstance(seq, (str, list, tuple)) and isinstance(number, int):
                    if len(seq) * number > 10000:
                        raise Unsupported('product size')
        if type(op) not in BIN:
            raise Unsupported(type(op).__name__)
        return self.bounded(BIN[type(op)](a, b))

    def expression(self, n):
        self.tick()
        if isinstance(n, ast.Constant):
            return self.bounded(n.value)
        if isinstance(n, ast.Name):
            return self.env[n.id]
        if isinstance(n, ast.BinOp):
            return self.binary(n.op, self.expression(n.left), self.expression(n.right))
        if isinstance(n, ast.UnaryOp):
            funcs = {ast.USub: operator.neg, ast.UAdd: operator.pos, ast.Not: operator.not_}
            return funcs[type(n.op)](self.expression(n.operand))
        if isinstance(n, ast.Compare):
            left = self.expression(n.left)
            for op, expr in zip(n.ops, n.comparators):
                right = self.expression(expr)
                if not CMP[type(op)](left, right):
                    return False
                left = right
            return True
        if isinstance(n, ast.BoolOp):
            value = None
            for child in n.values:
                value = self.expression(child)
                if isinstance(n.op, ast.And) and not value:
                    break
                if isinstance(n.op, ast.Or) and value:
                    break
            return value
        if isinstance(n, ast.IfExp):
            return self.expression(n.body if self.expression(n.test) else n.orelse)
        if isinstance(n, (ast.List, ast.Tuple)):
            result = [self.expression(x) for x in n.elts]
            return tuple(result) if isinstance(n, ast.Tuple) else result
        if isinstance(n, ast.Dict):
            return {self.expression(k): self.expression(v) for k, v in zip(n.keys, n.values)}
        if isinstance(n, ast.Subscript):
            return self.expression(n.value)[self.expression(n.slice)]
        if isinstance(n, ast.Attribute):
            if isinstance(n.value, ast.Name) and n.value.id == 'math' and n.attr in MATH:
                return MATH[n.attr]
            raise Unsupported('attribute access')
        if isinstance(n, ast.Call):
            fn = self.expression(n.func)
            args = [self.expression(x) for x in n.args]
            kwargs = {k.arg: self.expression(k.value) for k in n.keywords if k.arg is not None}
            if len(kwargs) != len(n.keywords):
                raise Unsupported('keyword expansion')
            if isinstance(fn, ast.FunctionDef):
                if self.depth >= 10:
                    raise Unsupported('call depth')
                old = self.env.copy()
                self.depth += 1
                try:
                    for a, v in zip(fn.args.args, args):
                        self.env[a.arg] = v
                    self.env.update(kwargs)
                    self.statements(fn.body)
                    return None
                except Returned as result:
                    return result.value
                finally:
                    self.env = old
                    self.depth -= 1
            if not any(fn is f for f in list(FUNCS.values()) + list(MATH.values()) if callable(f)):
                raise Unsupported('function call')
            if fn is pow and (len(args) < 2 or abs(args[1]) > 4096):
                raise Unsupported('power size')
            return self.bounded(fn(*args, **kwargs))
        raise Unsupported(type(n).__name__)

    def statements(self, nodes):
        for n in nodes:
            self.tick()
            if isinstance(n, ast.FunctionDef):
                if n.decorator_list:
                    raise Unsupported('decorator')
                self.env[n.name] = n
            elif isinstance(n, ast.Assign):
                value = self.expression(n.value)
                for t in n.targets:
                    self.assign(t, value)
            elif isinstance(n, ast.AnnAssign):
                self.assign(n.target, self.expression(n.value))
            elif isinstance(n, ast.AugAssign):
                self.assign(n.target, self.binary(n.op, self.expression(n.target), self.expression(n.value)))
            elif isinstance(n, ast.Return):
                raise Returned(self.expression(n.value) if n.value else None)
            elif isinstance(n, ast.If):
                self.statements(n.body if self.expression(n.test) else n.orelse)
            elif isinstance(n, ast.For):
                for v in self.expression(n.iter):
                    self.tick()
                    self.assign(n.target, v)
                    self.statements(n.body)
                self.statements(n.orelse)
            elif isinstance(n, ast.While):
                while self.expression(n.test):
                    self.tick()
                    self.statements(n.body)
                self.statements(n.orelse)
            elif isinstance(n, ast.Import):
                if any(a.name != 'math' or a.asname for a in n.names):
                    raise Unsupported('import')
            elif isinstance(n, ast.ImportFrom):
                source = MATH if n.module == 'math' else {'Fraction': Fraction} if n.module == 'fractions' else {}
                for a in n.names:
                    if a.name not in source:
                        raise Unsupported('import')
                    self.env[a.asname or a.name] = source[a.name]
            elif isinstance(n, ast.Expr):
                self.expression(n.value)
            elif not isinstance(n, ast.Pass):
                raise Unsupported(type(n).__name__)


def numeric_answer(code):
    try:
        tree = ast.parse(code)
        runner = Interpreter()
        runner.statements(tree.body)
        fn = runner.env.get('solve')
        if not isinstance(fn, ast.FunctionDef) or fn.args.args or fn.args.posonlyargs or fn.args.kwonlyargs or fn.args.vararg or fn.args.kwarg:
            return {'status': 'missing_solve', 'value': None}
        result = runner.expression(ast.Call(func=ast.Name(id='solve'), args=[], keywords=[]))
        value = float(result)
        if not math.isfinite(value):
            return {'status': 'nonfinite', 'value': None}
        return {'status': 'ok', 'value': value}
    except SyntaxError:
        return {'status': 'syntax', 'value': None}
    except Unsupported as error:
        return {'status': 'unsupported', 'value': None, 'detail': str(error)}
    except Exception as error:
        return {'status': 'runtime', 'value': None, 'detail': type(error).__name__}


def compare(predictions, references):
    if len(predictions) != len(references):
        raise ValueError('Prediction/reference count mismatch')
    from collections import Counter
    refs = [numeric_answer(x) for x in references]
    preds = [numeric_answer(x) for x in predictions]
    eligible = [i for i, r in enumerate(refs) if r['status'] == 'ok']
    correct = sum(preds[i]['status'] == 'ok' and math.isclose(preds[i]['value'], refs[i]['value'], rel_tol=1e-6, abs_tol=1e-6) for i in eligible)
    return {'rows': len(predictions), 'reference_eligible': len(eligible),
            'correct': correct, 'functional_accuracy': correct / len(eligible) if eligible else None,
            'prediction_status': dict(Counter(p['status'] for p in preds)),
            'reference_status': dict(Counter(p['status'] for p in refs)),
            'official_pass_at_1': False}
