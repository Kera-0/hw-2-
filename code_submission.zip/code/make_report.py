"""Render the report using recorded experiments and optional real T4 evidence."""
import argparse
import datetime
import json
from pathlib import Path
from xml.sax.saxutils import escape


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    parser.add_argument('--author')
    parser.add_argument('--group')
    parser.add_argument('--public-pass-at-1', type=float)
    parser.add_argument('--public-correct', type=int)
    parser.add_argument('--timing', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    read = lambda name: json.loads((root / name).read_text())
    saved_path = root / 'artifacts/report_updates.json'
    saved = json.loads(saved_path.read_text()) if saved_path.exists() else {}
    for key, value in [('author', args.author), ('group', args.group),
                       ('public_pass_at_1', args.public_pass_at_1), ('public_correct', args.public_correct)]:
        if value is not None:
            saved[key] = value
    public = saved.get('public_pass_at_1')
    if public is not None and not 0 <= public <= 100:
        raise ValueError('Public pass@1 must be a percentage between 0 and 100')
    correct = saved.get('public_correct')
    if correct is not None and (not 0 <= correct <= 960 or public is not None and abs(100 * correct / 960 - public) > 0.011):
        raise ValueError('Public numerator and percentage differ')
    if args.timing:
        saved['timing'] = json.loads(args.timing.read_text())
    state = read('artifacts/submission_state.json')
    timing = saved.get('timing')
    if timing:
        if timing.get('parameters') != 130183936 or timing.get('rows') != 1919 or not timing.get('actual_t4'):
            raise ValueError('Expected all 1919 questions on an actual T4')
        if timing.get('checkpoint_sha256') != state['checkpoint_sha256'] or timing.get('questions_sha256') != state['questions_sha256']:
            raise ValueError('T4 evidence belongs to different weights or questions')
        if not isinstance(timing.get('cold_subprocess_seconds'), (int, float)):
            raise ValueError('Fresh subprocess timing is required')
    saved_path.write_text(json.dumps(saved, ensure_ascii=False, indent=2) + '\n')
    state.update(v2_public_pass_at_1=public, actual_t4_timing=timing)
    (root / 'artifacts/submission_state.json').write_text(json.dumps(state, indent=2) + '\n')

    v2 = read('artifacts/v2/submission_130m_info.json')
    data = read('artifacts/v2/data_manifest.json')
    best = read('artifacts/v2/training_meta.json')
    old_meta = read('artifacts/first_130m/130m_training_meta.json')
    old_data = read('artifacts/first_130m/130m_data_manifest.json')
    summary = read('artifacts/v2/continuation_summary.json')
    old_lengths = read('artifacts/first_130m/baseline_length_experiments.json')
    first_lengths = read('artifacts/first_130m/decoding_experiments_130m.json')
    new_lengths = read('artifacts/v2/decoding_experiments_130m.json')
    events = [json.loads(line) for line in (root / 'artifacts/v2/metrics.jsonl').read_text().splitlines()]
    val = [row for row in events if row.get('kind') == 'validation']
    first_check = val[0]
    last_check = val[-1]
    other = read('history/code107m/results.json')
    final107 = other['final_metrics'][-1]
    blocks = []
    def text(value):
        blocks.append(('text', value))
    def heading(value):
        blocks.append(('heading', value))

    heading('Модель и данные')
    text('Я обучал модель, которая по тексту задачи пишет Python-функцию solve() с численным ответом. Для проверки нужны 1919 программ в исходном порядке. Главное ограничение — весь инференс на одной NVIDIA T4 должен занимать не больше 180 секунд.')
    text('Итоговая модель — BART-подобный Transformer на 130 183 936 параметров: 6 слоёв энкодера, 3 слоя декодера, ширина 1024, 16 голов внимания, FFN 3840 и dropout 0,1. Более короткий декодер уменьшает стоимость каждого нового токена. Первая 130M обучалась со случайной инициализации; V2 продолжает мой же checkpoint. Внешние предобученные веса не использовались.')
    text('Использован только SlavaYus/tinysms_qa_12m, ревизия b2724689ff079e9c22efd548fe134bfb29036dbb. Дополнительные данные для обучения, ответы других моделей и переписанные таргеты не создавались. Byte-level BPE на 8192 токена обучен на первых 50 тысячах train-пар первого запуска. Он сохраняет пробелы и отступы Python и повторно используется в 130M.')
    text(f'Нормализованный вопрос делится по SHA-256: около 2% групп исключаются из обучения на всех шардах. Для сравнения сохранены одни и те же 1024 валидационных вопроса. В V2 взяты все 60 train-шардов: {data["raw_rows"]:,} исходных строк; исключены {data["heldout_rows_excluded"]:,} строк валидационных групп и {data["overlength_rows_excluded"]:,} слишком длинных пар. Осталось {data["train_rows"]:,} примеров. Лимиты — 192 токена вопроса и 256 токенов программы. Такое разбиение защищает от нормализованных дублей, но не от похожих по смыслу задач.'.replace(',', ' '))
    heading('Как обучал')
    text('Оба запуска 130M выполнены на H100 80GB, с 32 CPU и 128 ГБ RAM. Использованы BF16, AdamW, weight decay 0,01, batch 128 с накоплением 2, seed 42 и cosine decay. В первом запуске было 40 000 шагов, learning rate 0,0003 и warmup 1000. Он занял около 63 минут по логу, без подготовки данных. Выбран шаг 38 000.')
    text('В V2 я увеличил выборку с 30 до 60 шардов и дообучил checkpoint шага 38 000 ещё 60 000 шагов: learning rate 0,00008, warmup 500. Само обучение заняло около 100 минут. Исходные веса и ответы сохранены отдельно. Токены записывались в Arrow; готовые шарды переиспользовались без изменения, батчи группировались по длине. В этом опыте одновременно изменены данные, learning rate и число шагов, поэтому вклад каждого изменения отдельно не измерен.')
    blocks.append(('table', [
        ['Запуск', 'Train-примеры', 'Шаги', 'Выбранный checkpoint'],
        ['77M', '978 505', '10 000', 'первый baseline'],
        ['130M', f'{old_data["train_rows"]:,}'.replace(',', ' '), '40 000', '38 000'],
        ['130M V2', f'{data["train_rows"]:,}'.replace(',', ' '), '+60 000', '38 000 + 50 000'],
    ]))
    text(f'Отдельно запускался предоставленный Code107M на 106 977 792 параметра, со своим токенизатором и split. Он завершил 90 000 шагов, но финальный val loss был {final107["val/nll"]:.2f}, а доля синтаксически корректных генераций — 0%. Этот checkpoint для итоговой посылки не использован. Причина неустойчивого обучения отдельно не установлена; исходники и результат сохранены в history/code107m.')
    continued107 = read('history/code107m_continuation/results/continuation_completed.json')
    recovery107 = continued107['recovery_check']
    text(f'Затем я попробовал продолжить 107M из last.pt шага 90 000, восстановив AdamW, RNG, собственный токенизатор и порядок данных. Learning rate снизил до 0,00001. После 2000 новых шагов loss уменьшился с 5,9413 до {continued107["best_nll"]:.4f}, но синтаксическая корректность осталась 0%. Сработало заранее заданное правило ранней остановки: нулевой синтаксис и снижение loss меньше 0,1. Опыт завершён на шаге 92 000; остальные 28 000 шагов не выполнялись. Продолжение не восстановило модель, и для сдачи по-прежнему выбрана 130M V2. Код и результаты лежат отдельно в history/code107m_continuation.')
    blocks.append(('pagebreak', ''))

    heading('Эксперименты и результат')
    text('Первая 77M при генерации до 64 токенов получила у бота 48,65% на public, 467 из 960. В тестовом JSONL 692 из 1919 генераций не достигли EOS. Я проверил больший лимит на том же checkpoint, затем сравнил его с 130M. Все числа в таблице ниже — локальная проверка, а не pass@1 бота.')
    table = [['Модель', 'Лимит токенов', 'Верно / 983', 'Локально, %']]
    for name, results in [('77M', old_lengths), ('130M', first_lengths), ('130M V2', new_lengths)]:
        table.extend([[name, str(row['limit']), str(row['correct']), f'{100 * row["functional_accuracy"]:.2f}'] for row in results])
    blocks.append(('table', table))
    text(f'У первой 130M было 685/983, или 69,68%. После первых 1000 шагов V2 результат упал до {first_check["correct"]}/983; к шагу 39 000 поднялся до 696/983. Лучший результат — {best["best_validation"]["correct"]}/983, или 70,91%, на шаге 50 000 продолжения. На последнем шаге 60 000 было {last_check["correct"]}/983. Поэтому для посылки выбран шаг 50 000: вместе с исходными 38 000 это 88 000 обновлений в цепочке выбранных весов. Прирост к первой 130M — 12 задач, около 1,22 процентного пункта; дополнительных шагов после пика оказалось недостаточно для дальнейшего роста.')
    text('Числа сравнивает ограниченный AST-интерпретатор. Он поддерживает 983 эталона из 1024; остальные не входят в знаменатель. Loss считается на 1021 примере, три длинных таргета исключены только из этой метрики. У выбранной V2 loss 0,2698, точность токенов 91,68%. Это диагностика по эталонному коду, а не официальный pass@1 и не проверка всей выборки в песочнице бота.')
    if public is None:
        text('Первая 130M получила у бота около 73%; точное значение этого ответа не записано. Официальный результат новой V2 пока не добавлен. Локальные 70,91% нельзя подставлять вместо него.')
    else:
        suffix = f', {correct} из 960' if correct is not None else ''
        text(f'Public pass@1 новой V2 по ответу бота — {public:.2f}%{suffix}. Для первой 130M ранее сообщалось около 73%; точное значение первого результата не сохранено.')
    heading('Скорость и сдача')
    text(f'Для инференса выбраны FP16, greedy decoding, KV-cache, batch 128 и сортировка вопросов по длине с восстановлением порядка. Лимит 192 токена даёт ту же локальную точность, что и 256, при меньшем времени. На H100 сама генерация 1919 программ заняла {v2["generation_seconds_h100"]:.2f} секунды; загрузка модели в этот замер не входит. У всех вопросов сохранён контекст, 6 генераций не достигли EOS. Вопросы взяты из официального test.parquet; независимая сверка порядка с файлом бота не выполнялась.')
    if timing:
        seconds = timing['cold_subprocess_seconds']
        verdict = 'Лимит выполнен.' if seconds <= 180 else 'Лимит не выполнен; этот запуск нельзя считать итоговой проверкой скорости.'
        text(f'На настоящей T4 все 1919 программ сгенерированы за {seconds:.2f} секунды. Batch {timing["batch_size"]}, лимит {timing["max_new_tokens"]} токенов. Замер в новом процессе включает импорты, проверку и распаковку архива, загрузку модели, токенизацию, генерацию и запись JSONL. {verdict}')
    else:
        text('Настоящий запуск на T4 ещё не выполнен. Подготовлен самостоятельный inference_t4.ipynb: он измеряет новый процесс целиком, включая импорты, проверку и распаковку архива, загрузку модели, токенизацию, генерацию и запись JSONL. Установка пакетов и загрузка файлов выполняются до таймера. До сдачи нужно сохранить выполненный notebook и добавить его время в этот отчёт.')
    text('ИИ-агент помог прочитать условие, написать код и проверки, организовать обучение на H100, разобрать обрыв генераций и собрать материалы. С его помощью появились Arrow-кэш, логи, отдельные папки экспериментов, сохранение лучшего checkpoint и замер T4 в новом процессе. Результаты я беру из логов и ответа бота; измерение T4 и оценку новой посылки заранее не подставляю.')

    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, PageBreak
    font = next(p for p in [Path('/System/Library/Fonts/Supplemental/Arial.ttf'),
                           Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')] if p.exists())
    pdfmetrics.registerFont(TTFont('Report', str(font)))
    body = ParagraphStyle('Body', fontName='Report', fontSize=10, leading=13.1, spaceAfter=6)
    title = ParagraphStyle('Title', parent=body, fontSize=16, leading=20, spaceAfter=10)
    head = ParagraphStyle('Head', parent=body, fontSize=11.5, leading=15, spaceBefore=5, spaceAfter=6)
    story = [Paragraph('Генерация Python-кода: 130M V2', title)]
    identity = ' · '.join(x for x in [saved.get('author'), saved.get('group')] if x)
    if identity:
        story.append(Paragraph(escape(identity), body))
    plain = ['Генерация Python-кода: 130M V2']
    for kind, value in blocks:
        if kind == 'table':
            table = Table(value, colWidths=[100, 120, 105, 190] if len(value) == 4 else [100, 135, 145, 135], repeatRows=1)
            table.setStyle(TableStyle([('FONTNAME', (0, 0), (-1, -1), 'Report'), ('FONTSIZE', (0, 0), (-1, -1), 9),
                                      ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eeeeee')),
                                      ('LINEBELOW', (0, 0), (-1, 0), .5, colors.grey),
                                      ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]))
            story.extend([table, Spacer(1, 6)])
            plain.append('\n'.join(' | '.join(row) for row in value))
        elif kind == 'pagebreak':
            story.append(PageBreak())
        else:
            story.append(Paragraph(escape(value), head if kind == 'heading' else body))
            plain.append(value)
    output = args.output or root.parent / 'report.pdf'
    output.parent.mkdir(parents=True, exist_ok=True)
    def footer(canvas, doc):
        canvas.setFont('Report', 8)
        canvas.drawString(40, 22, 'HSE NLP · HW2 · 130M V2')
        canvas.drawRightString(A4[0] - 40, 22, str(doc.page))
    SimpleDocTemplate(str(output), pagesize=A4, leftMargin=40, rightMargin=40,
                      topMargin=30, bottomMargin=34).build(story, onFirstPage=footer, onLaterPages=footer)
    (root / 'artifacts/report_text.txt').write_text('\n\n'.join(plain) + '\n')
    print(output)


if __name__ == '__main__':
    main()
