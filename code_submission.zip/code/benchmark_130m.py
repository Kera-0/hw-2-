"""Measure a fresh inference process on a real T4, without preloading Torch."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', default='checkpoint_130m.zip')
    parser.add_argument('--questions', default='questions_used.jsonl')
    parser.add_argument('--output', default='submission_130m.jsonl')
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--max-new-tokens', type=int, default=192)
    parser.add_argument('--allow-other-gpu', action='store_true')
    args = parser.parse_args()
    command = [sys.executable, str(Path(__file__).with_name('inference_130m.py')),
               '--checkpoint', args.checkpoint, '--questions', args.questions,
               '--output', args.output, '--batch-size', str(args.batch_size),
               '--max-new-tokens', str(args.max_new_tokens)]
    if args.allow_other_gpu:
        command.append('--allow-other-gpu')
    timing = Path(args.output).with_suffix('.timing.json')
    timing.unlink(missing_ok=True)
    started = time.perf_counter()
    process = subprocess.run(command, timeout=190)
    seconds = time.perf_counter() - started
    if not timing.exists():
        process.check_returncode()
        raise RuntimeError('Inference did not write a timing result')
    result = json.loads(timing.read_text())
    result.update(cold_subprocess_seconds=seconds,
                  t4_limit_verified=result['actual_t4'] and seconds <= 180,
                  within_180_seconds=seconds <= 180)
    timing.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    process.check_returncode()
    if not args.allow_other_gpu and not result['t4_limit_verified']:
        raise RuntimeError('The real T4 run exceeded 180 seconds')


if __name__ == '__main__':
    main()
